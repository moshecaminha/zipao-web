import React, { useState, useEffect, useRef } from "react";
import {
  LayoutDashboard, ShoppingCart, Boxes, ClipboardList, Printer, Calendar, Truck,
  Users, Gift, Wallet, MessageCircle, UserCog, Plug, BarChart3, Utensils, Coffee,
  Beef, Pizza, Cake, Croissant, Scale, Search, Bell, X, Check, Plus, Minus,
  CreditCard, QrCode, Banknote, AlertTriangle, ArrowRight, Upload, CheckCircle2,
  Circle, Clock, MapPin, LogOut, ShieldCheck, TrendingUp, Power, Menu, Store,
  ChevronRight, ChevronLeft, Smartphone, Receipt, Zap, Hash, User, PlayCircle, Star, Lock, Delete,
  ChefHat, Volume2, VolumeX, Bell as BellIcon, Navigation, Bike, ThumbsUp, ThumbsDown, Timer, Flame,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { supabase, STORE_ID } from "./supabaseClient";

// Categorias reais da loja (para o cadastro de produtos)
const CATEGORIAS = [
  { id: "cmq05qxob0004j5kv3nr8ckjo", name: "Pães" },
  { id: "cmq05qy5o0006j5kv38pbt9hj", name: "Bolos & Tortas" },
  { id: "cmq05qyn50008j5kvkzrdb3bs", name: "Salgados" },
  { id: "cmq05qz4n000aj5kvjyacf6qc", name: "Bebidas" },
];
const slugify = (s) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") + "-" + Math.random().toString(36).slice(2, 6);

/* ============================ Marca ============================ */
const ORANGE = "#FF5630";
const NAVY = "#1A2138";
const CREAM = "#F4F2EC";
const SOFT = "#FFF1EC";

const money = (n) => "R$ " + n.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/* ============================ Ícone da marca ============================ */
function ZipIcon({ size = 36, radius = 9 }) {
  const s = size / 100;
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-hidden="true">
      <rect x="0" y="0" width="100" height="100" rx={radius / s} fill={ORANGE} />
      <g transform="translate(16,16) scale(0.68)" stroke="#fff" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <line x1="6" y1="30" x2="28" y2="30" strokeWidth="6.5" opacity="0.9" />
        <line x1="2" y1="50" x2="24" y2="50" strokeWidth="6.5" opacity="0.7" />
        <line x1="6" y1="70" x2="28" y2="70" strokeWidth="6.5" opacity="0.9" />
        <path d="M48 27 H90 L40 73 H82" strokeWidth="11" />
      </g>
    </svg>
  );
}

/* ============================ Dados de exemplo ============================ */
const UNITS = [
  { k: "restaurante", label: "Restaurante", icon: Utensils },
  { k: "cafeteria", label: "Cafeteria", icon: Coffee },
  { k: "hamburgueria", label: "Hamburgueria", icon: Beef },
  { k: "pizzaria", label: "Pizzaria", icon: Pizza },
  { k: "doceria", label: "Doceria", icon: Cake },
  { k: "pastelaria", label: "Pastelaria", icon: Croissant },
  { k: "tipicas", label: "Típicas", icon: Utensils },
  { k: "pesagem", label: "Self-service (peso)", icon: Scale },
];

const PRODUTOS = {
  restaurante: [
    { n: "Prato executivo", p: 28.9 }, { n: "Strogonoff de frango", p: 32.0 },
    { n: "Filé acebolado", p: 39.9 }, { n: "Salada Caesar", p: 24.5 },
  ],
  cafeteria: [
    { n: "Café expresso", p: 6.0 }, { n: "Cappuccino", p: 11.0 },
    { n: "Pão na chapa", p: 9.5 }, { n: "Misto quente", p: 13.0 },
  ],
  hamburgueria: [
    { n: "Zip Burger clássico", p: 26.9 }, { n: "Cheddar bacon", p: 32.9 },
    { n: "Veggie", p: 28.0 }, { n: "Batata rústica", p: 18.0 },
  ],
  pizzaria: [
    { n: "Pizza margherita", p: 49.9 }, { n: "Pizza calabresa", p: 52.0 },
    { n: "Pizza portuguesa", p: 55.0 }, { n: "Broto doce", p: 32.0 },
  ],
  doceria: [
    { n: "Fatia de bolo", p: 12.0 }, { n: "Brigadeiro gourmet", p: 5.5 },
    { n: "Torta holandesa", p: 16.0 }, { n: "Pudim", p: 10.0 },
  ],
  pastelaria: [
    { n: "Pastel de carne", p: 9.0 }, { n: "Pastel de queijo", p: 9.0 },
    { n: "Caldo de cana 300ml", p: 8.0 }, { n: "Coxinha", p: 7.5 },
  ],
  tipicas: [
    { n: "Feijoada (porção)", p: 45.0 }, { n: "Acarajé", p: 18.0 },
    { n: "Tapioca recheada", p: 16.0 }, { n: "Caldo verde", p: 14.0 },
  ],
  pesagem: [{ n: "Buffet por kg", p: 69.9 }],
};

const INSUMOS = [
  { n: "Farinha de trigo", un: "kg", precoMed: 4.2, estoque: 180, min: 60, consumoDia: 35 },
  { n: "Açúcar refinado", un: "kg", precoMed: 5.1, estoque: 90, min: 40, consumoDia: 18 },
  { n: "Leite integral", un: "L", precoMed: 4.8, estoque: 120, min: 50, consumoDia: 40 },
  { n: "Fermento biológico", un: "kg", precoMed: 22.0, estoque: 8, min: 10, consumoDia: 2 },
  { n: "Manteiga", un: "kg", precoMed: 38.0, estoque: 25, min: 12, consumoDia: 6 },
  { n: "Carne moída (blend)", un: "kg", precoMed: 32.0, estoque: 44, min: 25, consumoDia: 14 },
  { n: "Queijo mussarela", un: "kg", precoMed: 41.0, estoque: 60, min: 30, consumoDia: 20 },
  { n: "Molho de tomate", un: "L", precoMed: 9.5, estoque: 70, min: 30, consumoDia: 15 },
  { n: "Caixa de hambúrguer", un: "un", precoMed: 0.9, estoque: 400, min: 200, consumoDia: 120 },
  { n: "Caixa de pizza", un: "un", precoMed: 2.3, estoque: 150, min: 120, consumoDia: 90 },
  { n: "Embalagem viagem 750ml", un: "un", precoMed: 0.75, estoque: 600, min: 250, consumoDia: 160 },
];

const FICHAS = [
  { prod: "Zip Burger clássico (viagem)", itens: ["Pão brioche x1", "Carne moída 180g", "Queijo mussarela 40g", "Caixa de hambúrguer x1"] },
  { prod: "Pizza margherita (viagem)", itens: ["Massa 320g", "Molho de tomate 120ml", "Queijo mussarela 150g", "Caixa de pizza x1"] },
  { prod: "Prato executivo (viagem)", itens: ["Arroz 200g", "Feijão 150g", "Proteína 180g", "Embalagem viagem 750ml x1"] },
];

const CLIENTES_INIC = [
  { n: "Marina Alves", tel: "(11) 99812-3344", zips: 320, gasto: 1240.5, cashback: true },
  { n: "Rafael Costa", tel: "(11) 99761-2210", zips: 85, gasto: 410.0, cashback: true },
  { n: "Júlia Mendes", tel: "(11) 99934-1100", zips: 0, gasto: 98.0, cashback: false },
  { n: "Pedro Santos", tel: "(11) 99877-5521", zips: 540, gasto: 2210.9, cashback: true },
];

const ENCOMENDAS = [
  { c: "Marina Alves", item: "Bolo 2kg chocolate", data: "16/06 14:00", status: "Em produção", valor: 180 },
  { c: "Festa Corp X", item: "100 salgados + 2 bolos", data: "18/06 09:00", status: "Confirmado", valor: 920 },
  { c: "Rafael Costa", item: "Torta holandesa G", data: "15/06 17:00", status: "Pronto p/ retirada", valor: 95 },
  { c: "Júlia Mendes", item: "20 cupcakes", data: "20/06 10:00", status: "Aguardando pagamento", valor: 160 },
];

const DELIVERIES = [
  { id: "#10482", c: "Pedro Santos", bairro: "Vila Mariana", mot: "Carlos", status: "A caminho", min: 12 },
  { id: "#10481", c: "Ana Lima", bairro: "Saúde", mot: "Bruno", status: "Saiu p/ entrega", min: 18 },
  { id: "#10480", c: "Marcos T.", bairro: "Ipiranga", mot: "—", status: "Em preparo", min: 25 },
];

const PDVS = [
  { n: "Caixa Balcão 1", local: "Frente de loja", status: "Online" },
  { n: "Caixa Restaurante", local: "Salão", status: "Online" },
  { n: "Totem Autoatendimento", local: "Entrada", status: "Offline" },
];

const USUARIOS = [
  { n: "Sr. Antônio (dono)", papel: "Administrador", acesso: "Total" },
  { n: "Fernanda", papel: "Gerente", acesso: "Operação + relatórios" },
  { n: "Lucas", papel: "Caixa", acesso: "PDV + clientes" },
  { n: "Bia", papel: "Produção", acesso: "Encomendas + estoque" },
];

const vendasSemana = [
  { d: "Seg", v: 4200 }, { d: "Ter", v: 3800 }, { d: "Qua", v: 5100 },
  { d: "Qui", v: 4700 }, { d: "Sex", v: 7300 }, { d: "Sáb", v: 9200 }, { d: "Dom", v: 6100 },
];
const vendasUnidade = [
  { u: "Restaur.", v: 12400 }, { u: "Pizzaria", v: 9800 }, { u: "Burger", v: 7600 },
  { u: "Café", v: 4200 }, { u: "Doceria", v: 3100 }, { u: "Pastel", v: 2600 },
];

/* ============================ UI base ============================ */
function Card({ children, className = "", style = {} }) {
  return <div className={"rounded-2xl bg-white border " + className} style={{ borderColor: "#ECECEC", ...style }}>{children}</div>;
}
function Section({ title, desc, children, right }) {
  return (
    <div>
      <div className="flex items-start justify-between gap-3 flex-wrap mb-4">
        <div>
          <h2 className="text-xl font-bold" style={{ color: NAVY }}>{title}</h2>
          {desc && <p className="text-sm mt-1" style={{ color: "#6B7280" }}>{desc}</p>}
        </div>
        {right}
      </div>
      {children}
    </div>
  );
}
function Pill({ children, tone = "gray" }) {
  const map = {
    green: ["#E7F6EC", "#1B7F4B"], orange: [SOFT, ORANGE], gray: ["#F1F2F4", "#4B5563"],
    blue: ["#E8F0FE", "#2563EB"], red: ["#FDECEC", "#C0392B"], navy: ["#E9EBF1", NAVY],
  };
  const [bg, c] = map[tone] || map.gray;
  return <span className="text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: bg, color: c }}>{children}</span>;
}
function Btn({ children, onClick, variant = "primary", className = "", icon: Icon, size = "md" }) {
  const pad = size === "sm" ? "px-3 py-1.5 text-sm" : "px-4 py-2.5";
  const styles =
    variant === "primary" ? { background: ORANGE, color: "#fff" }
    : variant === "navy" ? { background: NAVY, color: "#fff" }
    : variant === "ghost" ? { background: "transparent", color: NAVY, border: "1px solid #E2E2E2" }
    : { background: "#fff", color: NAVY, border: "1px solid #E2E2E2" };
  return (
    <button onClick={onClick} className={"rounded-xl font-semibold inline-flex items-center justify-center gap-2 transition active:scale-95 " + pad + " " + className} style={styles}>
      {Icon && <Icon size={16} />}{children}
    </button>
  );
}
function Toggle({ on, onChange }) {
  return (
    <button onClick={() => onChange(!on)} className="w-11 h-6 rounded-full transition relative" style={{ background: on ? ORANGE : "#D6D8DD" }} aria-pressed={on}>
      <span className="absolute top-0.5 h-5 w-5 bg-white rounded-full transition-all" style={{ left: on ? "22px" : "2px" }} />
    </button>
  );
}
function Stat({ icon: Icon, label, value, delta, tone = "orange" }) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div className="h-10 w-10 rounded-xl flex items-center justify-center" style={{ background: SOFT }}>
          <Icon size={20} color={ORANGE} />
        </div>
        {delta && <Pill tone="green">{delta}</Pill>}
      </div>
      <div className="mt-3 text-2xl font-bold" style={{ color: NAVY }}>{value}</div>
      <div className="text-sm" style={{ color: "#6B7280" }}>{label}</div>
    </Card>
  );
}

/* ============================ Planos / vendas ============================ */
const PLANOS = [
  { nome: "Início", preco: 89, sub: "Para começar a organizar", destaque: false, users: "1 usuário", whats: false, nf: "Não inclui", setup: null,
    bullets: ["1 usuário", "1 PDV", "Vendas + estoque básico", "Cardápio digital"] },
  { nome: "Balcão", preco: 199, sub: "Padaria de bairro", destaque: false, users: "3 usuários", whats: false, nf: "Até 100/mês", setup: null,
    bullets: ["3 usuários", "1 PDV", "NFC-e até 100/mês", "Clientes + cashback", "Relatórios"] },
  { nome: "Padaria", preco: 499, sub: "O mais escolhido · com WhatsApp", destaque: true, users: "6 usuários", whats: true, nf: "Até 500/mês", setup: 2800,
    bullets: ["6 usuários", "2 PDVs", "Pedidos por WhatsApp", "Delivery + encomendas", "NFC-e até 500/mês", "Clube de pontos"] },
  { nome: "Multi", preco: 899, sub: "Restaurante + café + delivery", destaque: false, users: "15 usuários", whats: true, nf: "Ilimitada", setup: 2800,
    bullets: ["15 usuários", "5 PDVs", "WhatsApp multi-atendente", "Todos os módulos", "NF-e/NFC-e ilimitada"] },
  { nome: "Rede", preco: null, sub: "Várias lojas e franquias", destaque: false, users: "Ilimitado", whats: true, nf: "Ilimitada", setup: 2800,
    bullets: ["Usuários ilimitados", "PDVs ilimitados", "Multi-lojas + API", "Gerente de conta", "NF-e ilimitada"] },
];
const FEATURES = [
  { icon: ShoppingCart, t: "PDV completo", d: "Mesa ou venda avulsa, comanda por nome e número, pesagem e pagamento." },
  { icon: Boxes, t: "Estoque inteligente", d: "Baixa por ficha técnica, preço médio e alerta de reposição." },
  { icon: Printer, t: "Fiscal & NFC-e", d: "Emissão de nota conectada à impressora fiscal e à SEFAZ." },
  { icon: Truck, t: "Delivery próprio", d: "Pedidos, entregadores e rastreio no estilo dos grandes apps." },
  { icon: Calendar, t: "Encomendas", d: "Bolos e festas agendados com acompanhamento de produção." },
  { icon: MessageCircle, t: "Pedidos no WhatsApp", d: "Receba e confirme pedidos direto na cozinha." },
  { icon: Gift, t: "Clube de pontos", d: "Cashback configurável com a moeda Zips." },
  { icon: Wallet, t: "Pagamentos", d: "Pix e cartão pelo Mercado Pago ou maquineta local." },
];
const OPERADORES = [
  { n: "Lucas", papel: "Caixa" }, { n: "Bia", papel: "Atendente" }, { n: "Fernanda", papel: "Gerente" },
];

function VideoModal({ onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(10,12,20,.85)" }}>
      <div className="w-full max-w-2xl">
        <div className="flex justify-end mb-2"><button onClick={onClose}><X size={22} color="#fff" /></button></div>
        <div className="rounded-2xl overflow-hidden" style={{ background: "#0B0E16", aspectRatio: "16 / 9" }}>
          <div className="h-full w-full flex flex-col items-center justify-center gap-3">
            <div className="h-16 w-16 rounded-full flex items-center justify-center" style={{ background: ORANGE }}><PlayCircle size={36} color="#fff" /></div>
            <div className="text-white font-semibold">Demonstração do Zipão ERP</div>
            <div className="text-white/50 text-sm">2 min · tour completo do sistema</div>
            <div className="w-2/3 h-1 rounded-full mt-2" style={{ background: "rgba(255,255,255,.15)" }}><div className="h-1 rounded-full" style={{ width: "35%", background: ORANGE }} /></div>
          </div>
        </div>
        <p className="text-white/50 text-xs mt-3 text-center">Espaço reservado para o vídeo demonstrativo (YouTube/Vimeo) na versão publicada.</p>
      </div>
    </div>
  );
}

function PlanCard({ p, onChoose }) {
  return (
    <div className="rounded-2xl bg-white border p-5 flex flex-col" style={{ borderColor: p.destaque ? ORANGE : "#ECECEC", borderWidth: p.destaque ? 2 : 1 }}>
      {p.destaque && <div className="inline-flex items-center gap-1 self-start text-xs font-bold px-2.5 py-1 rounded-full mb-2" style={{ background: SOFT, color: ORANGE }}><Star size={12} />Mais popular</div>}
      <h3 className="text-lg font-bold" style={{ color: NAVY }}>{p.nome}</h3>
      <p className="text-sm mb-3" style={{ color: "#9AA0A6" }}>{p.sub}</p>
      <div className="mb-3">
        {p.preco != null
          ? <div><span className="text-3xl font-bold" style={{ color: NAVY }}>{money(p.preco)}</span><span className="text-sm" style={{ color: "#9AA0A6" }}>/mês</span></div>
          : <div className="text-2xl font-bold" style={{ color: NAVY }}>Sob consulta</div>}
        {p.setup && <div className="text-xs mt-1" style={{ color: ORANGE }}>+ {money(p.setup)} implantação do WhatsApp (única vez)</div>}
      </div>
      <ul className="space-y-2 flex-1">
        {p.bullets.map((b) => <li key={b} className="flex items-start gap-2 text-sm" style={{ color: "#4B5563" }}><Check size={15} color="#1B7F4B" className="mt-0.5 shrink-0" />{b}</li>)}
      </ul>
      <button onClick={onChoose} className="mt-4 w-full rounded-xl font-semibold py-2.5" style={p.destaque ? { background: ORANGE, color: "#fff" } : { background: "#fff", color: NAVY, border: "1px solid #E2E2E2" }}>
        {p.preco != null ? "Assinar " + p.nome : "Falar com vendas"}
      </button>
    </div>
  );
}

function Landing({ onLogin, onCliente, toast }) {
  const [video, setVideo] = useState(false);
  const [ag, setAg] = useState({ nome: "", neg: "", tel: "", dia: "" });
  return (
    <div style={{ background: "#fff" }}>
      <header className="sticky top-0 z-40 border-b" style={{ background: "rgba(255,255,255,.92)", backdropFilter: "blur(8px)", borderColor: "#EEE" }}>
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-4">
          <div className="flex items-center gap-2"><ZipIcon size={32} /><span className="font-bold text-lg" style={{ color: NAVY, fontFamily: "Fredoka, sans-serif" }}>Zipão</span></div>
          <nav className="hidden md:flex items-center gap-6 ml-6 text-sm font-medium" style={{ color: "#4B5563" }}>
            <a href="#recursos">Recursos</a><a href="#planos">Planos</a><a href="#agendar">Agendar</a>
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={onLogin} className="text-sm font-semibold px-3 py-2 rounded-xl" style={{ color: NAVY }}>Entrar</button>
            <a href="#planos" className="text-sm font-semibold px-4 py-2 rounded-xl" style={{ background: ORANGE, color: "#fff" }}>Começar agora</a>
          </div>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-4 py-12 md:py-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <span className="text-xs font-bold px-3 py-1.5 rounded-full" style={{ background: SOFT, color: ORANGE }}>ERP + App de delivery num só lugar</span>
          <h1 className="text-4xl md:text-5xl font-bold mt-4 leading-tight" style={{ color: NAVY }}>O sistema que faz seu negócio voar.</h1>
          <p className="mt-4 text-lg" style={{ color: "#4B5563" }}>Estoque, fiscal, PDV, delivery, encomendas e clube de pontos — tudo integrado, do balcão à entrega. Pediu, zipou.</p>
          <div className="flex flex-wrap gap-3 mt-6">
            <a href="#agendar" className="rounded-xl font-semibold px-5 py-3 inline-flex items-center gap-2" style={{ background: ORANGE, color: "#fff" }}><Calendar size={18} />Agendar apresentação</a>
            <a href="#planos" className="rounded-xl font-semibold px-5 py-3 inline-flex items-center gap-2" style={{ border: "1px solid #E2E2E2", color: NAVY }}>Ver planos<ArrowRight size={16} /></a>
          </div>
        </div>
        <button onClick={() => setVideo(true)} className="relative w-full rounded-2xl overflow-hidden block" style={{ aspectRatio: "16 / 9", background: "linear-gradient(135deg, " + NAVY + ", #2b3553)" }}>
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
            <div className="h-16 w-16 rounded-full flex items-center justify-center shadow-lg" style={{ background: ORANGE }}><PlayCircle size={34} color="#fff" /></div>
            <span className="text-white font-semibold">Ver demonstração (2 min)</span>
          </div>
        </button>
      </section>

      <section className="border-y" style={{ borderColor: "#EEE", background: CREAM }}>
        <div className="max-w-6xl mx-auto px-4 py-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          {[["+1.200", "pedidos/dia"], ["8", "tipos de negócio"], ["100%", "configurável"], ["5 min", "para começar"]].map((s) => (
            <div key={s[1]}><div className="text-2xl font-bold" style={{ color: ORANGE }}>{s[0]}</div><div className="text-sm" style={{ color: "#6B7280" }}>{s[1]}</div></div>
          ))}
        </div>
      </section>

      <section id="recursos" className="max-w-6xl mx-auto px-4 py-14">
        <h2 className="text-3xl font-bold text-center" style={{ color: NAVY }}>Tudo num só sistema</h2>
        <p className="text-center mt-2 mb-8" style={{ color: "#6B7280" }}>Do pedido ao caixa, da cozinha à entrega.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {FEATURES.map((f) => (
            <div key={f.t} className="p-5 rounded-2xl border" style={{ borderColor: "#ECECEC" }}>
              <div className="h-11 w-11 rounded-xl flex items-center justify-center mb-3" style={{ background: SOFT }}><f.icon size={20} color={ORANGE} /></div>
              <h3 className="font-bold" style={{ color: NAVY }}>{f.t}</h3>
              <p className="text-sm mt-1" style={{ color: "#6B7280" }}>{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="planos" className="py-14" style={{ background: CREAM }}>
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center" style={{ color: NAVY }}>Planos para escalar com você</h2>
          <p className="text-center mt-2" style={{ color: "#6B7280" }}>Você paga pelo número de usuários. A nota fiscal entra conforme o plano.</p>
          <p className="text-center mt-1 mb-8 text-sm" style={{ color: ORANGE }}>Planos com WhatsApp partem de R$ 499/mês + implantação única de R$ 2.800.</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
            {PLANOS.map((p) => <PlanCard key={p.nome} p={p} onChoose={() => toast(p.preco != null ? "Plano " + p.nome + " selecionado" : "Pedido de contato enviado")} />)}
          </div>
          <div className="mt-6 overflow-x-auto">
            <table className="w-full text-sm bg-white rounded-2xl overflow-hidden border" style={{ borderColor: "#ECECEC" }}>
              <thead><tr><th className="text-left px-4 py-3 font-semibold" style={{ color: NAVY }}>Compare</th>{PLANOS.map((p) => <th key={p.nome} className="px-4 py-3 font-semibold" style={{ color: NAVY }}>{p.nome}</th>)}</tr></thead>
              <tbody>
                <tr className="border-t" style={{ borderColor: "#F0F0F0" }}><td className="px-4 py-3" style={{ color: "#4B5563" }}>Usuários</td>{PLANOS.map((p) => <td key={p.nome} className="px-4 py-3 text-center text-xs" style={{ color: NAVY }}>{p.users}</td>)}</tr>
                <tr className="border-t" style={{ borderColor: "#F0F0F0" }}><td className="px-4 py-3" style={{ color: "#4B5563" }}>WhatsApp</td>{PLANOS.map((p) => <td key={p.nome} className="px-4 py-3 text-center text-xs" style={{ color: p.whats ? NAVY : "#9AA0A6" }}>{p.whats ? "Sim · +R$ 2.800" : "—"}</td>)}</tr>
                <tr className="border-t" style={{ borderColor: "#F0F0F0" }}><td className="px-4 py-3" style={{ color: "#4B5563" }}>Notas fiscais</td>{PLANOS.map((p) => <td key={p.nome} className="px-4 py-3 text-center text-xs" style={{ color: NAVY }}>{p.nf}</td>)}</tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section id="agendar" className="max-w-6xl mx-auto px-4 py-14 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h2 className="text-3xl font-bold" style={{ color: NAVY }}>Agende uma apresentação</h2>
          <p className="mt-3" style={{ color: "#4B5563" }}>Mostramos o Zipão funcionando com o seu tipo de negócio em 30 minutos, online e sem compromisso.</p>
          <div className="mt-5 space-y-2 text-sm" style={{ color: "#4B5563" }}>
            <div className="flex items-center gap-2"><Check size={16} color="#1B7F4B" />Configuração inicial sem custo</div>
            <div className="flex items-center gap-2"><Check size={16} color="#1B7F4B" />Migração dos seus produtos</div>
            <div className="flex items-center gap-2"><Check size={16} color="#1B7F4B" />Treinamento da equipe</div>
          </div>
        </div>
        <Card className="p-6">
          <label className="text-sm font-medium" style={{ color: NAVY }}>Seu nome</label>
          <input value={ag.nome} onChange={(e) => setAg({ ...ag, nome: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
          <label className="text-sm font-medium" style={{ color: NAVY }}>Nome do negócio</label>
          <input value={ag.neg} onChange={(e) => setAg({ ...ag, neg: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-sm font-medium" style={{ color: NAVY }}>WhatsApp</label><input value={ag.tel} onChange={(e) => setAg({ ...ag, tel: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
            <div><label className="text-sm font-medium" style={{ color: NAVY }}>Melhor dia</label><input value={ag.dia} onChange={(e) => setAg({ ...ag, dia: e.target.value })} placeholder="Ex.: seg 14h" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
          </div>
          <Btn className="w-full" icon={Calendar} onClick={() => toast("Apresentação solicitada! Entraremos em contato.")}>Agendar apresentação</Btn>
        </Card>
      </section>

      <section className="py-12" style={{ background: NAVY }}>
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center gap-6 justify-between">
          <div><h2 className="text-2xl font-bold text-white">Seus clientes pedem pelo app Zipão</h2><p className="text-white/70 mt-2">Cardápio, delivery, pagamento e cashback na mão do cliente — incluso no seu plano.</p></div>
          <button onClick={onCliente} className="rounded-xl font-semibold px-5 py-3 inline-flex items-center gap-2 whitespace-nowrap" style={{ background: ORANGE, color: "#fff" }}><Smartphone size={18} />Ver app de pedidos</button>
        </div>
      </section>

      <footer className="max-w-6xl mx-auto px-4 py-8 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2"><ZipIcon size={26} /><span className="font-bold" style={{ color: NAVY, fontFamily: "Fredoka, sans-serif" }}>Zipão</span></div>
        <p className="text-sm" style={{ color: "#9AA0A6" }}>Pediu, zipou. · contato@zipao.com.br</p>
        <button onClick={onLogin} className="text-sm font-semibold" style={{ color: ORANGE }}>Entrar no sistema</button>
      </footer>

      {video && <VideoModal onClose={() => setVideo(false)} />}
    </div>
  );
}

/* ============================ Login PDV (atendente) ============================ */
function PDVLogin({ onBack, onEnter }) {
  const PLAN_SEATS = 6, ATIVOS = 3; // plano Padaria
  const [sel, setSel] = useState(null);
  const [pin, setPin] = useState("");
  const press = (d) => setPin((p) => (p.length < 4 ? p + d : p));
  const ok = sel && pin.length === 4;
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: NAVY }}>
      <Card className="w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2"><ZipIcon size={30} /><span className="font-bold" style={{ color: NAVY, fontFamily: "Fredoka, sans-serif" }}>Zipão PDV</span></div>
          <button onClick={onBack}><X size={20} color="#9AA0A6" /></button>
        </div>
        <p className="text-xs mb-4" style={{ color: "#9AA0A6" }}>Plano Padaria · {ATIVOS} de {PLAN_SEATS} usuários ativos</p>
        {!sel ? (
          <>
            <h3 className="font-bold mb-3" style={{ color: NAVY }}>Selecione o atendente</h3>
            <div className="space-y-2">
              {OPERADORES.map((o) => (
                <button key={o.n} onClick={() => { setSel(o); setPin(""); }} className="w-full flex items-center gap-3 p-3 rounded-xl border text-left" style={{ borderColor: "#E2E2E2" }}>
                  <div className="h-9 w-9 rounded-full flex items-center justify-center text-white font-bold text-sm" style={{ background: ORANGE }}>{o.n[0]}</div>
                  <div><div className="font-semibold text-sm" style={{ color: NAVY }}>{o.n}</div><div className="text-xs" style={{ color: "#9AA0A6" }}>{o.papel}</div></div>
                  <ChevronRight size={16} className="ml-auto" color="#9AA0A6" />
                </button>
              ))}
            </div>
            <div className="mt-4 p-3 rounded-xl text-xs flex items-start gap-2" style={{ background: SOFT, color: NAVY }}>
              <Lock size={14} color={ORANGE} className="mt-0.5 shrink-0" />Novos atendentes são adicionados em Usuários — cada um ocupa uma vaga do seu plano.
            </div>
          </>
        ) : (
          <>
            <button onClick={() => setSel(null)} className="text-sm inline-flex items-center gap-1 mb-3" style={{ color: "#6B7280" }}><ChevronLeft size={16} />Trocar atendente</button>
            <div className="text-center mb-3">
              <div className="h-12 w-12 rounded-full flex items-center justify-center text-white font-bold mx-auto mb-2" style={{ background: ORANGE }}>{sel.n[0]}</div>
              <div className="font-bold" style={{ color: NAVY }}>{sel.n}</div><div className="text-xs" style={{ color: "#9AA0A6" }}>Digite seu PIN de 4 dígitos</div>
            </div>
            <div className="flex justify-center gap-3 mb-4">{[0, 1, 2, 3].map((i) => <span key={i} className="h-3 w-3 rounded-full" style={{ background: i < pin.length ? ORANGE : "#E0E0E0" }} />)}</div>
            <div className="grid grid-cols-3 gap-2">
              {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((d) => <button key={d} onClick={() => press(d)} className="py-3 rounded-xl font-bold text-lg" style={{ background: "#F4F4F5", color: NAVY }}>{d}</button>)}
              <button onClick={() => setPin("")} className="py-3 rounded-xl text-sm font-semibold" style={{ background: "#F4F4F5", color: "#9AA0A6" }}>Limpar</button>
              <button onClick={() => press("0")} className="py-3 rounded-xl font-bold text-lg" style={{ background: "#F4F4F5", color: NAVY }}>0</button>
              <button onClick={() => setPin((p) => p.slice(0, -1))} className="py-3 rounded-xl flex items-center justify-center" style={{ background: "#F4F4F5" }}><Delete size={18} color={NAVY} /></button>
            </div>
            <Btn className="w-full mt-4" icon={ok ? Check : Lock} onClick={() => ok && onEnter(sel.n)}>Entrar no PDV</Btn>
          </>
        )}
      </Card>
    </div>
  );
}

/* ============================ Cadastro de entregador ============================ */
function CourierSignup({ onBack }) {
  const [f, setF] = useState({ name: "", phone: "", vehicleType: "Moto", email: "" });
  const [done, setDone] = useState(false);
  const [erro, setErro] = useState("");
  const enviar = async () => {
    if (!f.name || !f.phone) { setErro("Informe nome e telefone"); return; }
    setErro("");
    const { error } = await supabase.from("couriers").insert({ id: crypto.randomUUID(), storeId: STORE_ID, name: f.name, phone: f.phone, email: f.email || null, vehicleType: f.vehicleType, active: false, updatedAt: new Date().toISOString() });
    if (error) { setErro(error.message); return; }
    setDone(true);
  };
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: NAVY }}>
      <Card className="w-full max-w-sm p-6">
        <div className="flex items-center gap-2 mb-3"><ZipIcon size={30} /><span className="font-bold" style={{ color: NAVY, fontFamily: "Fredoka, sans-serif" }}>Zipão Entregador</span></div>
        {done ? (
          <div className="text-center py-6">
            <div className="h-12 w-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: SOFT }}><Check size={24} color={ORANGE} /></div>
            <h3 className="font-bold" style={{ color: NAVY }}>Cadastro enviado!</h3>
            <p className="text-sm mt-1" style={{ color: "#6B7280" }}>Seu acesso será liberado assim que o dono autorizar o seu cadastro.</p>
            <Btn variant="ghost" className="w-full mt-4" onClick={onBack}>Voltar</Btn>
          </div>
        ) : (
          <>
            <p className="text-sm mb-4" style={{ color: "#6B7280" }}>Cadastre-se para fazer entregas. O dono precisa aprovar antes de você ficar ativo.</p>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Nome completo</label>
            <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <div className="grid grid-cols-2 gap-2">
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Telefone</label><input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Veículo</label><select value={f.vehicleType} onChange={(e) => setF({ ...f, vehicleType: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm bg-white outline-none" style={{ borderColor: "#E2E2E2" }}>{["Moto", "Carro", "Bicicleta"].map((v) => <option key={v}>{v}</option>)}</select></div>
            </div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>E-mail</label>
            <input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} type="email" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            {erro && <p className="text-sm mb-2" style={{ color: "#C0392B" }}>{erro}</p>}
            <Btn className="w-full mt-1" icon={Bike} onClick={enviar}>Enviar cadastro</Btn>
            <button onClick={onBack} className="w-full mt-3 text-sm font-semibold" style={{ color: "#6B7280" }}>Voltar</button>
          </>
        )}
      </Card>
    </div>
  );
}

/* ============================ Login (hub) ============================ */
function Login({ onEnter, onDono }) {
  const [role, setRole] = useState(null);
  const [email, setEmail] = useState("paulomendescaminha@gmail.com");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(false);
  const entrar = async () => {
    setErro(""); setCarregando(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password: senha });
    setCarregando(false);
    if (error) { setErro("E-mail ou senha incorretos."); return; }
    unlockAudio(); beep();
    onDono();
  };
  const roles = [
    { k: "dono", label: "Dono / Gestor", desc: "Painel completo do ERP", icon: ShieldCheck },
    { k: "pdv", label: "Atendente (PDV)", desc: "Frente de caixa e comandas", icon: ShoppingCart },
    { k: "entregador", label: "Entregador", desc: "Cadastro e entregas", icon: Bike },
    { k: "cliente", label: "Cliente", desc: "Pedir e ver meus Zips", icon: Users },
  ];
  const irPara = (k) => k === "dono" ? setRole("dono") : onEnter(k === "pdv" ? "pdvlogin" : k === "entregador" ? "cadentregador" : "cliente");
  return (
    <div className="min-h-screen w-full flex" style={{ background: CREAM }}>
      <div className="hidden md:flex flex-col justify-between p-12 w-1/2" style={{ background: NAVY }}>
        <div className="flex items-center gap-3"><ZipIcon size={44} radius={12} /><span className="text-2xl font-bold text-white" style={{ fontFamily: "Fredoka, sans-serif" }}>Zipão</span></div>
        <div>
          <h1 className="text-white text-4xl font-bold leading-tight">O sistema que faz<br />seu negócio voar.</h1>
          <p className="text-white/70 mt-4 max-w-md">ERP completo de food service integrado ao app Zipão.</p>
        </div>
        <p className="text-white/40 text-sm">Pediu, zipou.</p>
      </div>
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <button onClick={() => onEnter("home")} className="text-sm mb-6 inline-flex items-center gap-1" style={{ color: "#6B7280" }}><ChevronLeft size={16} />Voltar ao site</button>
          <div className="md:hidden flex items-center gap-2 mb-6"><ZipIcon size={36} /><span className="text-xl font-bold" style={{ color: NAVY, fontFamily: "Fredoka, sans-serif" }}>Zipão</span></div>
          {!role ? (
            <>
              <h2 className="text-2xl font-bold" style={{ color: NAVY }}>Quem está entrando?</h2>
              <p className="text-sm mb-4" style={{ color: "#6B7280" }}>Escolha seu tipo de acesso.</p>
              <div className="space-y-2">
                {roles.map((r) => (
                  <button key={r.k} onClick={() => irPara(r.k)} className="w-full flex items-center gap-3 p-3 rounded-xl border text-left bg-white" style={{ borderColor: "#E2E2E2" }}>
                    <div className="h-10 w-10 rounded-xl flex items-center justify-center" style={{ background: SOFT }}><r.icon size={18} color={ORANGE} /></div>
                    <div><div className="font-semibold text-sm" style={{ color: NAVY }}>{r.label}</div><div className="text-xs" style={{ color: "#9AA0A6" }}>{r.desc}</div></div>
                    <ChevronRight size={16} className="ml-auto" color="#9AA0A6" />
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
              <h2 className="text-2xl font-bold" style={{ color: NAVY }}>Entrar como dono</h2>
              <p className="text-sm mb-5" style={{ color: "#6B7280" }}>Acesse o painel da sua loja.</p>
              <label className="text-sm font-medium" style={{ color: NAVY }}>E-mail</label>
              <input value={email} onChange={(e) => setEmail(e.target.value)} className="w-full mt-1 mb-4 px-4 py-3 rounded-xl border outline-none" style={{ borderColor: "#E2E2E2" }} />
              <label className="text-sm font-medium" style={{ color: NAVY }}>Senha</label>
              <input value={senha} onChange={(e) => setSenha(e.target.value)} type="password" placeholder="Sua senha" className="w-full mt-1 mb-3 px-4 py-3 rounded-xl border outline-none" style={{ borderColor: "#E2E2E2" }} />
              {erro && <p className="text-sm mb-3" style={{ color: "#C0392B" }}>{erro}</p>}
              <Btn onClick={entrar} className="w-full" icon={ShieldCheck}>{carregando ? "Entrando..." : "Entrar no painel"}</Btn>
              <button onClick={() => setRole(null)} className="w-full mt-3 text-sm font-semibold" style={{ color: "#6B7280" }}>Trocar perfil</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============================ Tour guiado ============================ */
const TOUR = [
  { m: "dashboard", t: "Visão geral", d: "O dono abre aqui e vê o pulso do negócio: vendas do dia, ticket médio, alertas de estoque baixo e o que está saindo agora. Cada número é um atalho." },
  { m: "pdv", t: "PDV / Frente de caixa", d: "Escolha a unidade (restaurante, burger, pizza...), monte a comanda em poucos toques e finalize. No fim, o pagamento e a nota saem juntos." },
  { m: "estoque", t: "Estoque & fichas técnicas", d: "Cada produto tem sua ficha: o burger de viagem já desconta o pão, a carne, o queijo E a caixa de hambúrguer. O estoque baixa sozinho a cada venda." },
  { m: "compras", t: "Compras & NF-e", d: "Importe o XML da nota do fornecedor: o sistema lê os itens, atualiza o preço médio de mercado e lança tudo no estoque automaticamente." },
  { m: "fiscal", t: "Fiscal & impressora", d: "Emissão de NFC-e e NF-e conectada à impressora fiscal. Acompanhe o status do equipamento e do certificado digital em tempo real." },
  { m: "encomendas", t: "Encomendas", d: "Bolos, festas e retiradas agendadas com data, hora e status de produção. O cliente acompanha pelo app." },
  { m: "clientes", t: "Clientes & cashback", d: "Cadastro completo. O cashback liga e desliga por cliente — você decide quem participa do clube." },
  { m: "pagamentos", t: "Pagamentos & PDVs", d: "Conecte o Mercado Pago para Pix e cartão online, configure a maquineta local e cadastre cada PDV da loja." },
  { m: "whatsapp", t: "Pedidos por WhatsApp", d: "Os pedidos chegam direto do WhatsApp para a fila da cozinha, com resposta automática. Sem digitar nada duas vezes." },
  { m: "integracoes", t: "Integrações", d: "Aqui ficam os códigos prontos para o seu dev plugar Mercado Pago, WhatsApp e nota fiscal no servidor. É só copiar." },
];
function Tour({ step, setStep, onModule, onClose }) {
  const s = TOUR[step];
  useEffect(() => { if (s) onModule(s.m); }, [step]);
  if (!s) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
      <Card className="w-full max-w-lg p-6" style={{ borderColor: ORANGE }}>
        <div className="flex items-center justify-between">
          <Pill tone="orange">Tour · {step + 1} de {TOUR.length}</Pill>
          <button onClick={onClose}><X size={20} color="#9AA0A6" /></button>
        </div>
        <h3 className="text-xl font-bold mt-3" style={{ color: NAVY }}>{s.t}</h3>
        <p className="mt-2 text-sm leading-relaxed" style={{ color: "#4B5563" }}>{s.d}</p>
        <div className="flex items-center gap-2 mt-5">
          <div className="flex-1 flex gap-1">
            {TOUR.map((_, i) => <span key={i} className="h-1.5 rounded-full flex-1" style={{ background: i <= step ? ORANGE : "#E6E6E6" }} />)}
          </div>
        </div>
        <div className="flex justify-between mt-5">
          <Btn variant="ghost" size="sm" icon={ChevronLeft} onClick={() => setStep(Math.max(0, step - 1))}>Anterior</Btn>
          {step < TOUR.length - 1
            ? <Btn size="sm" onClick={() => setStep(step + 1)}>Próximo <ChevronRight size={16} /></Btn>
            : <Btn size="sm" variant="navy" onClick={onClose} icon={Check}>Concluir tour</Btn>}
        </div>
      </Card>
    </div>
  );
}

/* ============================ Módulos ============================ */
function Dashboard({ toast }) {
  const [low, setLow] = useState([]);
  const [stats, setStats] = useState({ vendas: 0, pedidos: 0, ticket: 0 });
  const load = async () => {
    const ri = await supabase.from("ingredients").select("*").eq("storeId", STORE_ID);
    if (ri.data) setLow(ri.data.filter((i) => Number(i.stockQty) <= Number(i.minStock)));
    const rp = await supabase.from("pedidos").select("total, createdAt").eq("storeId", STORE_ID);
    if (rp.data) {
      const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
      const doDia = rp.data.filter((p) => new Date(p.createdAt) >= hoje);
      const soma = doDia.reduce((s, p) => s + Number(p.total || 0), 0);
      setStats({ vendas: soma, pedidos: doDia.length, ticket: doDia.length ? soma / doDia.length : 0 });
    }
  };
  useEffect(() => { load(); }, []);
  const gerarPedido = async () => {
    if (low.length === 0) return toast("Nenhum item em falta no momento.");
    const pid = crypto.randomUUID();
    const { error: e1 } = await supabase.from("purchases").insert({ id: pid, storeId: STORE_ID, supplier: "Pedido automático", status: "pedido", total: 0 });
    if (e1) return toast("Erro: " + e1.message);
    const items = low.map((i) => { const qtd = Math.max((Number(i.minStock) || 0) * 2 - Number(i.stockQty), Number(i.minStock) || 1); const uc = Number(i.avgPrice) || 0; return { purchaseId: pid, ingredientId: i.id, description: i.name, quantity: qtd, unit: i.unit, unitCost: uc, total: qtd * uc }; });
    const { error: e2 } = await supabase.from("purchase_items").insert(items);
    if (e2) return toast("Erro: " + e2.message);
    const tot = items.reduce((s, x) => s + x.total, 0);
    await supabase.from("purchases").update({ total: tot }).eq("id", pid);
    toast("Pedido de compra gerado com " + items.length + " item(ns). Veja na aba Compras.");
  };
  return (
    <Section title="Visão geral" desc="Tudo o que está acontecendo na sua loja agora.">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat icon={TrendingUp} label="Vendas hoje" value={money(stats.vendas)} delta="" />
        <Stat icon={Receipt} label="Pedidos hoje" value={String(stats.pedidos)} delta="" />
        <Stat icon={Wallet} label="Ticket médio" value={money(stats.ticket)} delta="" />
        <Stat icon={Gift} label="Itens em falta" value={String(low.length)} delta="" />
      </div>
      <div className="grid lg:grid-cols-3 gap-4 mt-4">
        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold" style={{ color: NAVY }}>Vendas na semana</h3><Pill tone="navy">Resumo</Pill>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={vendasSemana}>
              <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={ORANGE} stopOpacity={0.4} /><stop offset="100%" stopColor={ORANGE} stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="d" tick={{ fontSize: 12, fill: "#9AA0A6" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: "#9AA0A6" }} axisLine={false} tickLine={false} width={40} />
              <Tooltip formatter={(v) => money(v)} />
              <Area type="monotone" dataKey="v" stroke={ORANGE} strokeWidth={3} fill="url(#g)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card className="p-5">
          <h3 className="font-bold mb-3" style={{ color: NAVY }}>Estoque baixo</h3>
          <div className="space-y-3">
            {low.length === 0 && <p className="text-sm" style={{ color: "#9AA0A6" }}>Tudo abastecido.</p>}
            {low.map((i) => (
              <div key={i.id} className="flex items-center justify-between">
                <div className="flex items-center gap-2"><AlertTriangle size={16} color={ORANGE} /><span className="text-sm" style={{ color: NAVY }}>{i.name}</span></div>
                <span className="text-sm font-semibold" style={{ color: ORANGE }}>{Number(i.stockQty)} {i.unit}</span>
              </div>
            ))}
            <Btn variant="ghost" size="sm" className="w-full mt-1" icon={ClipboardList} onClick={gerarPedido}>Gerar pedido de compra</Btn>
          </div>
        </Card>
      </div>
      <Card className="p-5 mt-4">
        <h3 className="font-bold mb-3" style={{ color: NAVY }}>Vendas por unidade</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={vendasUnidade}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" vertical={false} />
            <XAxis dataKey="u" tick={{ fontSize: 12, fill: "#9AA0A6" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 12, fill: "#9AA0A6" }} axisLine={false} tickLine={false} width={50} />
            <Tooltip formatter={(v) => money(v)} />
            <Bar dataKey="v" fill={NAVY} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </Section>
  );
}

function catColor(k) {
  const m = { restaurante: "#E8590C", cafeteria: "#8B5E34", hamburgueria: "#C0392B", pizzaria: "#D35400", doceria: "#C2185B", pastelaria: "#B8860B", tipicas: "#2E7D32", pesagem: "#1565C0" };
  return m[k] || ORANGE;
}
function ProdFoto({ catK, h = 88 }) {
  const U = UNITS.find((u) => u.k === catK); const I = U ? U.icon : Utensils; const c = catColor(catK);
  return <div className="w-full rounded-xl flex items-center justify-center mb-3" style={{ height: h, background: "linear-gradient(135deg, " + c + ", " + c + "bb)" }}><I size={Math.round(h * 0.4)} color="rgba(255,255,255,.92)" /></div>;
}

function PDV({ toast }) {
  const [view, setView] = useState("lista");
  const [comandas, setComandas] = useState([
    { id: 1, numero: 12, nome: "Marina Alves", tipo: "mesa", mesa: "12", itens: [{ n: "Pizza calabresa", p: 52, q: 1, cat: "pizzaria" }] },
    { id: 2, numero: 13, nome: "João P.", tipo: "avulso", mesa: null, itens: [] },
  ]);
  const [activeId, setActiveId] = useState(null);
  const [seq, setSeq] = useState(14);
  const [cat, setCat] = useState("restaurante");
  const [novo, setNovo] = useState(null);
  const [nome, setNome] = useState("");
  const [mesa, setMesa] = useState("");
  const [qtyProd, setQtyProd] = useState(null);
  const [qtd, setQtd] = useState(1);
  const [pesoProd, setPesoProd] = useState(null);
  const [kg, setKg] = useState("0.500");
  const [pay, setPay] = useState(false);

  const active = comandas.find((c) => c.id === activeId);
  const totalOf = (c) => c.itens.reduce((s, x) => s + (x.isPeso ? x.p * x.peso : x.p * x.q), 0);

  const abrir = (tipo) => { setNovo({ tipo }); setNome(tipo === "avulso" ? "Avulso" : ""); setMesa(""); };
  const confirmarAbrir = () => {
    const id = Date.now();
    const c = { id, numero: seq, nome: nome || "Cliente", tipo: novo.tipo, mesa: novo.tipo === "mesa" ? (mesa || String(seq)) : null, itens: [] };
    setComandas((cs) => [...cs, c]); setSeq((s) => s + 1); setActiveId(id); setNovo(null); setCat("restaurante"); setView("pedido");
  };
  const retomar = (id) => { setActiveId(id); setView("pedido"); };
  const addItem = (prod, q) => setComandas((cs) => cs.map((c) => {
    if (c.id !== activeId) return c;
    const f = c.itens.find((x) => x.n === prod.n && !x.isPeso);
    const itens = f ? c.itens.map((x) => x === f ? { ...x, q: x.q + q } : x) : [...c.itens, { ...prod, q, cat }];
    return { ...c, itens };
  }));
  const addPeso = (prod, peso) => setComandas((cs) => cs.map((c) => c.id === activeId ? { ...c, itens: [...c.itens, { ...prod, isPeso: true, peso, cat }] } : c));
  const decLine = (idx) => setComandas((cs) => cs.map((c) => {
    if (c.id !== activeId) return c;
    const itens = c.itens.flatMap((x, i) => i === idx ? (x.isPeso || x.q <= 1 ? [] : [{ ...x, q: x.q - 1 }]) : [x]);
    return { ...c, itens };
  }));
  const tocarProduto = (p) => { if (cat === "pesagem") { setPesoProd(p); setKg("0.500"); } else { setQtyProd(p); setQtd(1); } };
  const finalizar = (m) => { setPay(false); setComandas((cs) => cs.filter((c) => c.id !== activeId)); setActiveId(null); setView("lista"); toast("Comanda fechada · pago " + m + " · NFC-e emitida"); };

  if (view === "lista") {
    return (
      <Section title="PDV / Frente de caixa" desc="Abra uma mesa, faça uma venda avulsa ou retome uma comanda.">
        <div className="grid sm:grid-cols-2 gap-3 mb-6">
          <button onClick={() => abrir("mesa")} className="p-5 rounded-2xl text-left text-white transition active:scale-95" style={{ background: NAVY }}>
            <Utensils size={22} /><div className="font-bold mt-3">Abrir mesa</div><div className="text-sm text-white/70">Comanda por mesa, fecha no fim</div>
          </button>
          <button onClick={() => abrir("avulso")} className="p-5 rounded-2xl text-left text-white transition active:scale-95" style={{ background: ORANGE }}>
            <ShoppingCart size={22} /><div className="font-bold mt-3">Venda avulsa</div><div className="text-sm text-white/80">Balcão, pagamento imediato</div>
          </button>
        </div>
        <h3 className="font-bold mb-3" style={{ color: NAVY }}>Comandas abertas</h3>
        {comandas.length === 0 ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Nenhuma comanda aberta.</p> : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {comandas.map((c) => (
              <button key={c.id} onClick={() => retomar(c.id)} className="text-left p-4 rounded-2xl bg-white border hover:shadow-md transition" style={{ borderColor: "#ECECEC" }}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-9 w-9 rounded-xl flex items-center justify-center" style={{ background: SOFT }}><Hash size={16} color={ORANGE} /></div>
                    <div><div className="font-bold" style={{ color: NAVY }}>Comanda {c.numero}</div><div className="text-xs" style={{ color: "#9AA0A6" }}>{c.nome}</div></div>
                  </div>
                  <Pill tone={c.tipo === "mesa" ? "navy" : "orange"}>{c.tipo === "mesa" ? "Mesa " + c.mesa : "Avulso"}</Pill>
                </div>
                <div className="flex items-center justify-between mt-3 pt-3 border-t" style={{ borderColor: "#F0F0F0" }}>
                  <span className="text-xs" style={{ color: "#9AA0A6" }}>{c.itens.length} item(ns)</span>
                  <span className="font-bold" style={{ color: NAVY }}>{money(totalOf(c))}</span>
                </div>
              </button>
            ))}
          </div>
        )}
        {novo && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
            <Card className="w-full max-w-sm p-6">
              <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>{novo.tipo === "mesa" ? "Abrir mesa" : "Venda avulsa"}</h3><button onClick={() => setNovo(null)}><X size={20} color="#9AA0A6" /></button></div>
              <p className="text-sm mb-3" style={{ color: "#6B7280" }}>Comanda número <b style={{ color: ORANGE }}>{seq}</b></p>
              <label className="text-sm font-medium" style={{ color: NAVY }}>Nome do cliente</label>
              <div className="flex items-center gap-2 mt-1 mb-3 px-3 rounded-xl border" style={{ borderColor: "#E2E2E2" }}>
                <User size={16} color="#9AA0A6" /><input value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Marina" className="flex-1 py-2.5 outline-none text-sm bg-transparent" />
              </div>
              {novo.tipo === "mesa" && (<>
                <label className="text-sm font-medium" style={{ color: NAVY }}>Número da mesa</label>
                <input value={mesa} onChange={(e) => setMesa(e.target.value)} placeholder="Ex.: 12" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
              </>)}
              <Btn className="w-full" onClick={confirmarAbrir} icon={Check}>Abrir comanda</Btn>
            </Card>
          </div>
        )}
      </Section>
    );
  }

  const prods = PRODUTOS[cat] || [];
  return (
    <Section title={"Comanda " + (active ? active.numero : "")} desc={active ? (active.nome + (active.tipo === "mesa" ? " · Mesa " + active.mesa : " · Venda avulsa")) : ""}
      right={<Btn variant="ghost" size="sm" icon={ChevronLeft} onClick={() => setView("lista")}>Voltar</Btn>}>
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <div className="flex gap-2 overflow-x-auto pb-2 mb-3">
            {UNITS.map((u) => { const on = cat === u.k; const I = u.icon; return (
              <button key={u.k} onClick={() => setCat(u.k)} className="px-3 py-2 rounded-xl text-sm font-semibold whitespace-nowrap inline-flex items-center gap-2" style={on ? { background: NAVY, color: "#fff" } : { background: "#fff", color: NAVY, border: "1px solid #E2E2E2" }}><I size={16} />{u.label}</button>
            ); })}
          </div>
          <div className="grid grid-cols-2 xl:grid-cols-3 gap-3">
            {prods.map((p) => (
              <button key={p.n} onClick={() => tocarProduto(p)} className="text-left p-3 rounded-2xl bg-white border hover:shadow-md transition active:scale-95" style={{ borderColor: "#ECECEC" }}>
                <ProdFoto catK={cat} />
                <div className="font-semibold text-sm leading-tight" style={{ color: NAVY }}>{p.n}</div>
                <div className="text-sm mt-0.5" style={{ color: ORANGE }}>{money(p.p)}{cat === "pesagem" ? " /kg" : ""}</div>
              </button>
            ))}
          </div>
        </div>
        <Card className="p-5 h-fit">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold" style={{ color: NAVY }}>Itens</h3>
            <Pill tone={active && active.tipo === "mesa" ? "navy" : "orange"}>{active && active.tipo === "mesa" ? "Mesa " + active.mesa : "Avulso"}</Pill>
          </div>
          {(!active || active.itens.length === 0) && <p className="text-sm py-8 text-center" style={{ color: "#9AA0A6" }}>Toque num produto para lançar.</p>}
          <div className="space-y-3">
            {active && active.itens.map((x, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="text-sm" style={{ color: NAVY }}>
                  <div className="font-medium">{x.n}</div>
                  <div style={{ color: "#9AA0A6" }}>{x.isPeso ? x.peso.toFixed(3) + " kg × " + money(x.p) + "/kg" : money(x.p)}</div>
                </div>
                <div className="flex items-center gap-2">
                  {!x.isPeso && <span className="text-sm font-semibold" style={{ color: "#9AA0A6" }}>{x.q}×</span>}
                  <span className="text-sm font-semibold" style={{ color: NAVY }}>{money(x.isPeso ? x.p * x.peso : x.p * x.q)}</span>
                  <button onClick={() => decLine(i)} className="h-7 w-7 rounded-lg flex items-center justify-center" style={{ background: "#F1F2F4" }}><Minus size={14} /></button>
                </div>
              </div>
            ))}
          </div>
          {active && active.itens.length > 0 && (<>
            <div className="flex justify-between mt-4 pt-4 border-t" style={{ borderColor: "#EEE" }}>
              <span className="font-semibold" style={{ color: NAVY }}>Total</span><span className="font-bold text-lg" style={{ color: NAVY }}>{money(totalOf(active))}</span>
            </div>
            <Btn className="w-full mt-4" icon={CreditCard} onClick={() => setPay(true)}>Finalizar e cobrar</Btn>
          </>)}
        </Card>
      </div>

      {qtyProd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-1"><h3 className="font-bold" style={{ color: NAVY }}>{qtyProd.n}</h3><button onClick={() => setQtyProd(null)}><X size={20} color="#9AA0A6" /></button></div>
            <p className="text-sm mb-4" style={{ color: "#6B7280" }}>{money(qtyProd.p)} cada</p>
            <div className="flex items-center justify-center gap-4 mb-4">
              <button onClick={() => setQtd((q) => Math.max(1, q - 1))} className="h-11 w-11 rounded-xl flex items-center justify-center" style={{ background: "#F1F2F4" }}><Minus size={18} /></button>
              <span className="text-3xl font-bold w-12 text-center" style={{ color: NAVY }}>{qtd}</span>
              <button onClick={() => setQtd((q) => q + 1)} className="h-11 w-11 rounded-xl flex items-center justify-center" style={{ background: SOFT }}><Plus size={18} color={ORANGE} /></button>
            </div>
            <div className="flex gap-2 mb-4">{[1, 2, 3, 4, 5].map((n) => <button key={n} onClick={() => setQtd(n)} className="flex-1 py-2 rounded-lg text-sm font-semibold" style={{ background: qtd === n ? NAVY : "#F4F4F5", color: qtd === n ? "#fff" : NAVY }}>{n}</button>)}</div>
            <Btn className="w-full" icon={Check} onClick={() => { addItem(qtyProd, qtd); toast(qtd + "× " + qtyProd.n + " lançado"); setQtyProd(null); }}>Lançar {money(qtyProd.p * qtd)}</Btn>
          </Card>
        </div>
      )}

      {pesoProd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-1"><div className="flex items-center gap-2"><Scale size={18} color={ORANGE} /><h3 className="font-bold" style={{ color: NAVY }}>Pesar — {pesoProd.n}</h3></div><button onClick={() => setPesoProd(null)}><X size={20} color="#9AA0A6" /></button></div>
            <p className="text-sm mb-4" style={{ color: "#6B7280" }}>{money(pesoProd.p)}/kg · informe o peso da balança</p>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Peso (kg)</label>
            <input value={kg} onChange={(e) => setKg(e.target.value)} type="number" step="0.001" min="0" className="w-full mt-1 mb-3 px-3 py-3 rounded-xl border text-lg font-semibold outline-none" style={{ borderColor: "#E2E2E2", color: NAVY }} />
            <div className="flex justify-between mb-4 p-3 rounded-xl" style={{ background: SOFT }}><span className="text-sm" style={{ color: NAVY }}>Total</span><span className="font-bold" style={{ color: ORANGE }}>{money(pesoProd.p * (parseFloat(kg) || 0))}</span></div>
            <Btn className="w-full" icon={Check} onClick={() => { const v = parseFloat(kg) || 0; if (v > 0) { addPeso(pesoProd, v); toast(v.toFixed(3) + " kg lançado"); } setPesoProd(null); }}>Lançar no sistema</Btn>
          </Card>
        </div>
      )}

      {pay && active && <PayModal total={totalOf(active)} onClose={() => setPay(false)} onDone={finalizar} />}
    </Section>
  );
}

function PayModal({ total, onClose, onDone }) {
  const opts = [
    { k: "Pix (Mercado Pago)", icon: QrCode }, { k: "Cartão na maquineta", icon: CreditCard },
    { k: "Cartão online (MP)", icon: Smartphone }, { k: "Dinheiro", icon: Banknote },
  ];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
      <Card className="w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-1"><h3 className="text-lg font-bold" style={{ color: NAVY }}>Pagamento</h3><button onClick={onClose}><X size={20} color="#9AA0A6" /></button></div>
        <p className="text-sm mb-4" style={{ color: "#6B7280" }}>Total a cobrar: <b style={{ color: NAVY }}>{money(total)}</b></p>
        <div className="space-y-2">
          {opts.map((o) => { const I = o.icon; return (
            <button key={o.k} onClick={() => onDone(o.k)} className="w-full flex items-center gap-3 p-3 rounded-xl border hover:shadow-sm transition text-left" style={{ borderColor: "#E2E2E2" }}>
              <div className="h-9 w-9 rounded-lg flex items-center justify-center" style={{ background: SOFT }}><I size={18} color={ORANGE} /></div>
              <span className="font-medium text-sm" style={{ color: NAVY }}>{o.k}</span><ArrowRight size={16} className="ml-auto" color="#9AA0A6" />
            </button>
          ); })}
        </div>
        <div className="flex items-center gap-2 mt-4 text-xs" style={{ color: "#9AA0A6" }}><Printer size={14} /> Impressora fiscal conectada · NFC-e automática</div>
      </Card>
    </div>
  );
}

function Estoque({ toast }) {
  const [insumos, setInsumos] = useState([]);
  const [produtos, setProdutos] = useState([]);
  const [fichas, setFichas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formIns, setFormIns] = useState(null);
  const [formFicha, setFormFicha] = useState(null);

  const load = async () => {
    setLoading(true);
    const [ri, rp] = await Promise.all([
      supabase.from("ingredients").select("*").eq("storeId", STORE_ID).order("name"),
      supabase.from("products").select("id,name").eq("storeId", STORE_ID).order("name"),
    ]);
    if (ri.error) toast("Erro: " + ri.error.message); else setInsumos(ri.data || []);
    if (rp.data) setProdutos(rp.data);
    const ids = (rp.data || []).map((p) => p.id);
    if (ids.length) {
      const rr = await supabase.from("recipe_items").select("*").in("productId", ids);
      setFichas(rr.data || []);
    } else setFichas([]);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const nomeIns = (id) => (insumos.find((i) => i.id === id) || {}).name || "?";
  const nomeProd = (id) => (produtos.find((p) => p.id === id) || {}).name || "?";

  // ---- Insumos ----
  const salvarIns = async () => {
    const f = formIns;
    if (!f.name) return toast("Informe o nome");
    const payload = { name: f.name, unit: f.unit, avgPrice: Number(f.avgPrice) || 0, stockQty: Number(f.stockQty) || 0, minStock: Number(f.minStock) || 0, dailyConsumption: Number(f.dailyConsumption) || 0, isPackaging: !!f.isPackaging };
    let error;
    if (f.id) ({ error } = await supabase.from("ingredients").update({ ...payload, updatedAt: new Date().toISOString() }).eq("id", f.id));
    else ({ error } = await supabase.from("ingredients").insert({ ...payload, storeId: STORE_ID }));
    if (error) return toast("Erro: " + error.message);
    toast(f.id ? "Insumo atualizado" : "Insumo cadastrado"); setFormIns(null); load();
  };
  const excluirIns = async (i) => {
    if (!window.confirm('Excluir "' + i.name + '"?')) return;
    const { error } = await supabase.from("ingredients").delete().eq("id", i.id);
    if (error) return toast("Erro: " + error.message + " (talvez esteja em uso numa ficha)");
    toast("Insumo excluído"); load();
  };

  // ---- Fichas técnicas ----
  const abrirFicha = () => setFormFicha({ productId: produtos[0]?.id || "", linhas: [{ ingredientId: insumos[0]?.id || "", quantity: "", unit: "" }] });
  const salvarFicha = async () => {
    const f = formFicha;
    if (!f.productId) return toast("Escolha o produto");
    const rows = f.linhas.filter((l) => l.ingredientId && l.quantity).map((l) => ({
      productId: f.productId, ingredientId: l.ingredientId, quantity: Number(l.quantity), unit: l.unit || (insumos.find((i) => i.id === l.ingredientId) || {}).unit,
    }));
    if (!rows.length) return toast("Adicione ao menos um insumo");
    const { error } = await supabase.from("recipe_items").upsert(rows, { onConflict: "productId,ingredientId" });
    if (error) return toast("Erro: " + error.message);
    toast("Ficha técnica salva"); setFormFicha(null); load();
  };
  const excluirLinha = async (l) => {
    const { error } = await supabase.from("recipe_items").delete().eq("id", l.id);
    if (error) return toast("Erro: " + error.message);
    load();
  };

  const fichasPorProduto = produtos.map((p) => ({ p, linhas: fichas.filter((f) => f.productId === p.id) })).filter((x) => x.linhas.length);

  return (
    <Section title="Estoque & fichas técnicas" desc="Cadastre insumos e monte as fichas técnicas — tudo gravado no banco.">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold" style={{ color: NAVY }}>Insumos</h3>
        <Btn size="sm" icon={Plus} onClick={() => setFormIns({ name: "", unit: "kg", avgPrice: "", stockQty: "", minStock: "", dailyConsumption: "", isPackaging: false })}>Novo insumo</Btn>
      </div>
      {loading ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Carregando...</p> : (
        <Card className="p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr style={{ background: CREAM }}>{["Insumo", "Preço médio", "Estoque", "Mín.", "Status", ""].map((h) => <th key={h} className="text-left px-4 py-3 font-semibold" style={{ color: NAVY }}>{h}</th>)}</tr></thead>
              <tbody>
                {insumos.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center" style={{ color: "#9AA0A6" }}>Nenhum insumo ainda.</td></tr>}
                {insumos.map((i) => { const low = Number(i.stockQty) <= Number(i.minStock); return (
                  <tr key={i.id} className="border-t" style={{ borderColor: "#F0F0F0" }}>
                    <td className="px-4 py-3 font-medium" style={{ color: NAVY }}>{i.name}{i.isPackaging ? " (embalagem)" : ""}</td>
                    <td className="px-4 py-3" style={{ color: "#4B5563" }}>{money(Number(i.avgPrice))}/{i.unit}</td>
                    <td className="px-4 py-3" style={{ color: "#4B5563" }}>{Number(i.stockQty)} {i.unit}</td>
                    <td className="px-4 py-3" style={{ color: "#9AA0A6" }}>{Number(i.minStock)}</td>
                    <td className="px-4 py-3">{low ? <Pill tone="red">Repor</Pill> : <Pill tone="green">OK</Pill>}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button onClick={() => setFormIns({ id: i.id, name: i.name, unit: i.unit, avgPrice: String(i.avgPrice), stockQty: String(i.stockQty), minStock: String(i.minStock), dailyConsumption: String(i.dailyConsumption), isPackaging: i.isPackaging })} className="text-sm font-semibold mr-3" style={{ color: NAVY }}>Editar</button>
                      <button onClick={() => excluirIns(i)} className="text-sm font-semibold" style={{ color: "#C0392B" }}>Excluir</button>
                    </td>
                  </tr>
                ); })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <div className="flex items-center justify-between mt-6 mb-3">
        <h3 className="font-bold" style={{ color: NAVY }}>Fichas técnicas</h3>
        <Btn size="sm" icon={Plus} onClick={abrirFicha}>Nova ficha técnica</Btn>
      </div>
      {fichasPorProduto.length === 0 ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Nenhuma ficha técnica. Clique em "Nova ficha técnica".</p> : (
        <div className="grid md:grid-cols-3 gap-4">
          {fichasPorProduto.map(({ p, linhas }) => (
            <Card key={p.id} className="p-5">
              <div className="flex items-center gap-2 mb-3"><Boxes size={18} color={ORANGE} /><span className="font-semibold text-sm" style={{ color: NAVY }}>{p.name}</span></div>
              <ul className="space-y-2">{linhas.map((l) => (
                <li key={l.id} className="text-sm flex items-center justify-between" style={{ color: "#4B5563" }}>
                  <span className="flex items-center gap-2"><Check size={14} color="#1B7F4B" />{Number(l.quantity)} {l.unit || ""} {nomeIns(l.ingredientId)}</span>
                  <button onClick={() => excluirLinha(l)} style={{ color: "#C0392B" }}><X size={14} /></button>
                </li>
              ))}</ul>
            </Card>
          ))}
        </div>
      )}

      {formIns && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>{formIns.id ? "Editar insumo" : "Novo insumo"}</h3><button onClick={() => setFormIns(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Nome</label>
            <input value={formIns.name} onChange={(e) => setFormIns({ ...formIns, name: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Unidade</label>
                <select value={formIns.unit} onChange={(e) => setFormIns({ ...formIns, unit: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm bg-white outline-none" style={{ borderColor: "#E2E2E2" }}>
                  {["kg", "L", "un"].map((u) => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Preço médio</label><input value={formIns.avgPrice} onChange={(e) => setFormIns({ ...formIns, avgPrice: e.target.value })} type="number" step="0.01" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Estoque</label><input value={formIns.stockQty} onChange={(e) => setFormIns({ ...formIns, stockQty: e.target.value })} type="number" step="0.001" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Estoque mínimo</label><input value={formIns.minStock} onChange={(e) => setFormIns({ ...formIns, minStock: e.target.value })} type="number" step="0.001" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
            </div>
            <label className="flex items-center justify-between py-1"><span className="text-sm font-medium" style={{ color: NAVY }}>É embalagem?</span><Toggle on={formIns.isPackaging} onChange={(v) => setFormIns({ ...formIns, isPackaging: v })} /></label>
            <Btn className="w-full mt-3" icon={Check} onClick={salvarIns}>{formIns.id ? "Salvar alterações" : "Cadastrar"}</Btn>
          </Card>
        </div>
      )}

      {formFicha && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>Nova ficha técnica</h3><button onClick={() => setFormFicha(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Produto</label>
            <select value={formFicha.productId} onChange={(e) => setFormFicha({ ...formFicha, productId: e.target.value })} className="w-full mt-1 mb-4 px-3 py-2.5 rounded-xl border text-sm bg-white outline-none" style={{ borderColor: "#E2E2E2" }}>
              {produtos.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Insumos da receita</label>
            <div className="space-y-2 mt-1 mb-3">
              {formFicha.linhas.map((l, idx) => (
                <div key={idx} className="flex gap-2">
                  <select value={l.ingredientId} onChange={(e) => { const ls = [...formFicha.linhas]; ls[idx] = { ...ls[idx], ingredientId: e.target.value }; setFormFicha({ ...formFicha, linhas: ls }); }} className="flex-1 px-2 py-2 rounded-lg border text-sm bg-white outline-none" style={{ borderColor: "#E2E2E2" }}>
                    {insumos.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
                  </select>
                  <input value={l.quantity} onChange={(e) => { const ls = [...formFicha.linhas]; ls[idx] = { ...ls[idx], quantity: e.target.value }; setFormFicha({ ...formFicha, linhas: ls }); }} type="number" step="0.001" placeholder="Qtd" className="w-20 px-2 py-2 rounded-lg border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                  <button onClick={() => setFormFicha({ ...formFicha, linhas: formFicha.linhas.filter((_, i) => i !== idx) })} className="px-2" style={{ color: "#C0392B" }}><X size={16} /></button>
                </div>
              ))}
            </div>
            <button onClick={() => setFormFicha({ ...formFicha, linhas: [...formFicha.linhas, { ingredientId: insumos[0]?.id || "", quantity: "", unit: "" }] })} className="text-sm font-semibold mb-4 inline-flex items-center gap-1" style={{ color: ORANGE }}><Plus size={14} />Adicionar insumo</button>
            <Btn className="w-full" icon={Check} onClick={salvarFicha}>Salvar ficha técnica</Btn>
          </Card>
        </div>
      )}
    </Section>
  );
}

function Compras({ toast }) {
  const [insumos, setInsumos] = useState([]);
  const [pos, setPos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const nomeIns = (id) => (insumos.find((i) => i.id === id) || {});

  const load = async () => {
    setLoading(true);
    const ri = await supabase.from("ingredients").select("id,name,unit,avgPrice,stockQty").eq("storeId", STORE_ID).order("name");
    setInsumos(ri.data || []);
    const rp = await supabase.from("purchases").select("*").eq("storeId", STORE_ID).order("createdAt", { ascending: false });
    const purchases = rp.data || [];
    const ids = purchases.map((p) => p.id);
    const itemsByP = {};
    if (ids.length) { const rit = await supabase.from("purchase_items").select("*").in("purchaseId", ids); (rit.data || []).forEach((it) => { (itemsByP[it.purchaseId] = itemsByP[it.purchaseId] || []).push(it); }); }
    setPos(purchases.map((p) => ({ ...p, items: itemsByP[p.id] || [] })));
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const aplicarEstoque = async (items) => {
    for (const it of items) {
      if (!it.ingredientId) continue;
      const { data: ing } = await supabase.from("ingredients").select("stockQty, avgPrice").eq("id", it.ingredientId).single();
      if (!ing) continue;
      const oldQty = Number(ing.stockQty) || 0, oldAvg = Number(ing.avgPrice) || 0;
      const q = Number(it.quantity) || 0, uc = Number(it.unitCost) || 0;
      const newQty = oldQty + q;
      const newAvg = newQty > 0 ? (oldQty * oldAvg + q * uc) / newQty : oldAvg;
      await supabase.from("ingredients").update({ stockQty: newQty, avgPrice: newAvg, updatedAt: new Date().toISOString() }).eq("id", it.ingredientId);
      await supabase.from("stock_movements").insert({ ingredientId: it.ingredientId, type: "in", quantity: q, unitCost: uc, reason: "compra" });
    }
  };
  const receber = async (po) => {
    if (!po.items.length) return toast("Pedido sem itens");
    await aplicarEstoque(po.items);
    await supabase.from("purchases").update({ status: "received" }).eq("id", po.id);
    toast("Estoque atualizado pela compra (preço médio recalculado)."); load();
  };
  const salvarCompra = async () => {
    const rows = form.linhas.filter((l) => l.ingredientId && l.quantity);
    if (!rows.length) return toast("Adicione ao menos um item");
    const pid = crypto.randomUUID();
    const tot = rows.reduce((s, l) => s + Number(l.quantity) * Number(l.unitCost || 0), 0);
    const e1 = await supabase.from("purchases").insert({ id: pid, storeId: STORE_ID, supplier: form.supplier || "Compra manual", status: "received", total: tot });
    if (e1.error) return toast("Erro: " + e1.error.message);
    await supabase.from("purchase_items").insert(rows.map((l) => ({ purchaseId: pid, ingredientId: l.ingredientId, description: nomeIns(l.ingredientId).name, quantity: Number(l.quantity), unit: nomeIns(l.ingredientId).unit, unitCost: Number(l.unitCost || 0), total: Number(l.quantity) * Number(l.unitCost || 0) })));
    await aplicarEstoque(rows);
    toast("Compra lançada e estoque atualizado."); setForm(null); load();
  };

  const pendentes = pos.filter((p) => p.status === "pedido");
  const recebidas = pos.filter((p) => p.status !== "pedido");

  return (
    <Section title="Compras & entrada de estoque" desc="Lance compras e receba os pedidos: o estoque e o preço médio são atualizados na hora." right={<Btn icon={Plus} onClick={() => setForm({ supplier: "", linhas: [{ ingredientId: insumos[0]?.id || "", quantity: "", unitCost: "" }] })}>Nova compra</Btn>}>
      {loading ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Carregando...</p> : (<>
        <h3 className="font-bold mb-2" style={{ color: NAVY }}>Pedidos de compra pendentes</h3>
        {pendentes.length === 0 ? <p className="text-sm mb-5" style={{ color: "#9AA0A6" }}>Nenhum pedido pendente. Você pode gerar um na Visão geral (estoque baixo) ou lançar uma compra manual.</p> : (
          <div className="space-y-3 mb-6">
            {pendentes.map((po) => (
              <Card key={po.id} className="p-4">
                <div className="flex items-center justify-between mb-2"><div className="font-semibold text-sm" style={{ color: NAVY }}>{po.supplier} · {money(Number(po.total))}</div><Pill tone="orange">Pendente</Pill></div>
                <ul className="text-sm space-y-1 mb-3" style={{ color: "#4B5563" }}>{po.items.map((it) => <li key={it.id}>{Number(it.quantity)} {it.unit || ""} {it.description || nomeIns(it.ingredientId).name} · {money(Number(it.unitCost))}/un</li>)}</ul>
                <Btn size="sm" icon={Boxes} onClick={() => receber(po)}>Receber no estoque</Btn>
              </Card>
            ))}
          </div>
        )}
        <h3 className="font-bold mb-2" style={{ color: NAVY }}>Compras recebidas</h3>
        {recebidas.length === 0 ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Nenhuma compra lançada ainda.</p> : (
          <Card className="p-0 overflow-hidden">
            <table className="w-full text-sm">
              <thead><tr style={{ background: CREAM }}>{["Fornecedor", "Itens", "Total", "Quando"].map((h) => <th key={h} className="text-left px-4 py-3 font-semibold" style={{ color: NAVY }}>{h}</th>)}</tr></thead>
              <tbody>{recebidas.map((po) => (
                <tr key={po.id} className="border-t" style={{ borderColor: "#F0F0F0" }}>
                  <td className="px-4 py-3 font-medium" style={{ color: NAVY }}>{po.supplier}</td>
                  <td className="px-4 py-3" style={{ color: "#4B5563" }}>{po.items.length}</td>
                  <td className="px-4 py-3" style={{ color: "#4B5563" }}>{money(Number(po.total))}</td>
                  <td className="px-4 py-3" style={{ color: "#9AA0A6" }}>{new Date(po.createdAt).toLocaleDateString("pt-BR")}</td>
                </tr>
              ))}</tbody>
            </table>
          </Card>
        )}
      </>)}

      {form && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>Nova compra</h3><button onClick={() => setForm(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Fornecedor</label>
            <input value={form.supplier} onChange={(e) => setForm({ ...form, supplier: e.target.value })} placeholder="Nome do fornecedor" className="w-full mt-1 mb-4 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <label className="text-sm font-medium" style={{ color: NAVY }}>Itens comprados</label>
            <div className="space-y-2 mt-1 mb-3">
              {form.linhas.map((l, idx) => (
                <div key={idx} className="flex gap-2">
                  <select value={l.ingredientId} onChange={(e) => { const ls = [...form.linhas]; ls[idx] = { ...ls[idx], ingredientId: e.target.value }; setForm({ ...form, linhas: ls }); }} className="flex-1 px-2 py-2 rounded-lg border text-sm bg-white outline-none" style={{ borderColor: "#E2E2E2" }}>{insumos.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select>
                  <input value={l.quantity} onChange={(e) => { const ls = [...form.linhas]; ls[idx] = { ...ls[idx], quantity: e.target.value }; setForm({ ...form, linhas: ls }); }} type="number" step="0.001" placeholder="Qtd" className="w-16 px-2 py-2 rounded-lg border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                  <input value={l.unitCost} onChange={(e) => { const ls = [...form.linhas]; ls[idx] = { ...ls[idx], unitCost: e.target.value }; setForm({ ...form, linhas: ls }); }} type="number" step="0.01" placeholder="R$/un" className="w-20 px-2 py-2 rounded-lg border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                  <button onClick={() => setForm({ ...form, linhas: form.linhas.filter((_, i) => i !== idx) })} className="px-1" style={{ color: "#C0392B" }}><X size={16} /></button>
                </div>
              ))}
            </div>
            <button onClick={() => setForm({ ...form, linhas: [...form.linhas, { ingredientId: insumos[0]?.id || "", quantity: "", unitCost: "" }] })} className="text-sm font-semibold mb-4 inline-flex items-center gap-1" style={{ color: ORANGE }}><Plus size={14} />Adicionar item</button>
            <Btn className="w-full" icon={Boxes} onClick={salvarCompra}>Lançar no estoque</Btn>
          </Card>
        </div>
      )}
    </Section>
  );
}

function Fiscal({ toast }) {
  return (
    <Section title="Fiscal & impressora" desc="Emissão de NFC-e e NF-e com integração à impressora fiscal e certificado digital.">
      <div className="grid md:grid-cols-3 gap-4 mb-4">
        <Card className="p-5"><div className="flex items-center gap-2 mb-2"><Printer size={18} color="#1B7F4B" /><span className="font-semibold text-sm" style={{ color: NAVY }}>Impressora fiscal</span></div><Pill tone="green">Conectada · Epson TM-T20</Pill></Card>
        <Card className="p-5"><div className="flex items-center gap-2 mb-2"><ShieldCheck size={18} color="#1B7F4B" /><span className="font-semibold text-sm" style={{ color: NAVY }}>Certificado A1</span></div><Pill tone="green">Válido até 02/2027</Pill></Card>
        <Card className="p-5"><div className="flex items-center gap-2 mb-2"><Zap size={18} color={ORANGE} /><span className="font-semibold text-sm" style={{ color: NAVY }}>SEFAZ</span></div><Pill tone="green">Online · autorizando</Pill></Card>
      </div>
      <Card className="p-5">
        <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>Últimas notas emitidas</h3><Btn size="sm" variant="ghost" icon={Receipt} onClick={() => toast("A emissão real de NFC-e precisa do certificado A1 e do servidor fiscal.")}>Sobre a emissão</Btn></div>
        <div className="space-y-2">
          {[["NFC-e 4421", "Balcão 1", "R$ 46,90", "Autorizada"], ["NFC-e 4420", "Restaurante", "R$ 128,00", "Autorizada"], ["NF-e 889", "Festa Corp X", "R$ 920,00", "Autorizada"]].map((r) => (
            <div key={r[0]} className="flex items-center justify-between p-3 rounded-xl" style={{ background: "#FAFAFA" }}>
              <div className="text-sm"><span className="font-semibold" style={{ color: NAVY }}>{r[0]}</span> <span style={{ color: "#9AA0A6" }}>· {r[1]}</span></div>
              <div className="flex items-center gap-3"><span className="text-sm font-medium" style={{ color: NAVY }}>{r[2]}</span><Pill tone="green">{r[3]}</Pill></div>
            </div>
          ))}
        </div>
      </Card>
    </Section>
  );
}

function Encomendas({ toast }) {
  const STATUS = ["Aguardando pagamento", "Confirmado", "Em produção", "Pronto p/ retirada", "Entregue"];
  const tone = (s) => s.includes("Aguardando") ? "red" : s.includes("Pronto") ? "green" : s.includes("Confirmado") ? "blue" : s.includes("Entregue") ? "navy" : "orange";
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("encomendas").select("*").eq("storeId", STORE_ID).order("quando");
    if (error) toast("Erro: " + error.message); else setList(data || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);
  const salvar = async () => {
    if (!form.cliente || !form.item) return toast("Preencha cliente e item");
    const payload = { cliente: form.cliente, item: form.item, valor: Number(form.valor) || 0, status: form.status, quando: form.quando ? new Date(form.quando).toISOString() : null };
    let error;
    if (form.id) ({ error } = await supabase.from("encomendas").update(payload).eq("id", form.id));
    else ({ error } = await supabase.from("encomendas").insert({ ...payload, storeId: STORE_ID }));
    if (error) return toast("Erro: " + error.message);
    toast(form.id ? "Encomenda atualizada" : "Encomenda criada"); setForm(null); load();
  };
  const excluir = async (e) => { if (!window.confirm("Excluir encomenda de " + e.cliente + "?")) return; const { error } = await supabase.from("encomendas").delete().eq("id", e.id); if (error) return toast("Erro: " + error.message); toast("Excluída"); load(); };
  const fmt = (s) => s ? new Date(s).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "—";
  return (
    <Section title="Gestão de encomendas" desc="Pedidos agendados, gravados no banco." right={<Btn icon={Plus} onClick={() => setForm({ cliente: "", item: "", valor: "", status: STATUS[0], quando: "" })}>Nova encomenda</Btn>}>
      {loading ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Carregando...</p> : list.length === 0 ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Nenhuma encomenda. Clique em "Nova encomenda".</p> : (
        <div className="grid md:grid-cols-2 gap-4">
          {list.map((e) => (
            <Card key={e.id} className="p-5">
              <div className="flex items-start justify-between"><div><div className="font-semibold" style={{ color: NAVY }}>{e.item}</div><div className="text-sm mt-1" style={{ color: "#6B7280" }}>{e.cliente}</div></div><Pill tone={tone(e.status)}>{e.status}</Pill></div>
              <div className="flex items-center justify-between mt-4 pt-4 border-t" style={{ borderColor: "#F0F0F0" }}>
                <div className="flex items-center gap-2 text-sm" style={{ color: "#4B5563" }}><Calendar size={15} />{fmt(e.quando)}</div>
                <div className="font-bold" style={{ color: ORANGE }}>{money(Number(e.valor))}</div>
              </div>
              <div className="flex gap-3 mt-3">
                <button onClick={() => setForm({ id: e.id, cliente: e.cliente, item: e.item, valor: String(e.valor), status: e.status, quando: e.quando ? e.quando.slice(0, 16) : "" })} className="text-sm font-semibold" style={{ color: NAVY }}>Editar</button>
                <button onClick={() => excluir(e)} className="text-sm font-semibold" style={{ color: "#C0392B" }}>Excluir</button>
              </div>
            </Card>
          ))}
        </div>
      )}
      {form && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>{form.id ? "Editar encomenda" : "Nova encomenda"}</h3><button onClick={() => setForm(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Cliente</label>
            <input value={form.cliente} onChange={(e) => setForm({ ...form, cliente: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <label className="text-sm font-medium" style={{ color: NAVY }}>Item</label>
            <input value={form.item} onChange={(e) => setForm({ ...form, item: e.target.value })} placeholder="Ex.: Bolo 2kg chocolate" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Valor (R$)</label><input value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} type="number" step="0.01" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Quando</label><input value={form.quando} onChange={(e) => setForm({ ...form, quando: e.target.value })} type="datetime-local" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
            </div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Status</label>
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm bg-white outline-none" style={{ borderColor: "#E2E2E2" }}>{STATUS.map((s) => <option key={s} value={s}>{s}</option>)}</select>
            <Btn className="w-full mt-1" icon={Check} onClick={salvar}>{form.id ? "Salvar" : "Criar encomenda"}</Btn>
          </Card>
        </div>
      )}
    </Section>
  );
}

function Delivery({ toast }) {
  const tone = (s) => s.includes("caminho") ? "orange" : s.includes("Saiu") ? "blue" : "gray";
  const [couriers, setCouriers] = useState([]);
  const [form, setForm] = useState(null);
  const load = async () => {
    const { data, error } = await supabase.from("couriers").select("*").eq("storeId", STORE_ID).order("createdAt", { ascending: false });
    if (error) toast("Erro: " + error.message); else setCouriers(data || []);
  };
  useEffect(() => { load(); }, []);
  const aprovar = async (c, v) => { setCouriers((l) => l.map((x) => x.id === c.id ? { ...x, active: v } : x)); const { error } = await supabase.from("couriers").update({ active: v, updatedAt: new Date().toISOString() }).eq("id", c.id); if (error) { toast("Erro: " + error.message); load(); } else toast(v ? "Entregador autorizado" : "Acesso suspenso"); };
  const salvar = async () => {
    if (!form.name || !form.phone) return toast("Informe nome e telefone");
    const { error } = await supabase.from("couriers").insert({ id: crypto.randomUUID(), storeId: STORE_ID, name: form.name, phone: form.phone, email: form.email || null, vehicleType: form.vehicleType || null, active: true, updatedAt: new Date().toISOString() });
    if (error) return toast("Erro: " + error.message);
    toast("Entregador cadastrado e ativo"); setForm(null); load();
  };
  const excluir = async (c) => { if (!window.confirm("Excluir " + c.name + "?")) return; const { error } = await supabase.from("couriers").delete().eq("id", c.id); if (error) return toast("Erro: " + error.message); toast("Removido"); load(); };
  return (
    <Section title="Delivery" desc="Pedidos em rota e gestão de entregadores (você autoriza quem fica ativo).">
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-3">
          {DELIVERIES.map((d) => (
            <Card key={d.id} className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl flex items-center justify-center" style={{ background: SOFT }}><Truck size={18} color={ORANGE} /></div>
                <div><div className="font-semibold text-sm" style={{ color: NAVY }}>{d.id} · {d.c}</div><div className="text-sm flex items-center gap-1" style={{ color: "#9AA0A6" }}><MapPin size={13} />{d.bairro} · {d.mot}</div></div>
              </div>
              <div className="text-right"><Pill tone={tone(d.status)}>{d.status}</Pill><div className="text-sm mt-1 flex items-center gap-1 justify-end" style={{ color: "#4B5563" }}><Clock size={13} />{d.min} min</div></div>
            </Card>
          ))}
        </div>
        <Card className="p-5">
          <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>Entregadores</h3><div className="flex gap-2"><button onClick={load} className="text-sm font-semibold" style={{ color: NAVY }}>Atualizar</button><Btn variant="ghost" size="sm" icon={Plus} onClick={() => setForm({ name: "", phone: "", email: "", vehicleType: "Moto" })}>Cadastrar</Btn></div></div>
          {couriers.length === 0 && <p className="text-sm" style={{ color: "#9AA0A6" }}>Nenhum entregador. Eles podem se cadastrar pela tela de entrada e aparecem aqui pra você autorizar.</p>}
          {couriers.map((c) => (
            <div key={c.id} className="flex items-center justify-between py-2 border-b" style={{ borderColor: "#F2F2F2" }}>
              <div><div className="text-sm font-medium" style={{ color: NAVY }}>{c.name}</div><div className="text-xs" style={{ color: "#9AA0A6" }}>{c.phone}{c.vehicleType ? " · " + c.vehicleType : ""}</div></div>
              <div className="flex items-center gap-2">
                <span className="text-xs" style={{ color: c.active ? "#1B7F4B" : "#C0392B" }}>{c.active ? "Ativo" : "Pendente"}</span>
                <Toggle on={c.active} onChange={(v) => aprovar(c, v)} />
                <button onClick={() => excluir(c)} style={{ color: "#C0392B" }}><X size={14} /></button>
              </div>
            </div>
          ))}
        </Card>
      </div>
      {form && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>Cadastrar entregador</h3><button onClick={() => setForm(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Nome</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Telefone</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Veículo</label>
                <select value={form.vehicleType} onChange={(e) => setForm({ ...form, vehicleType: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm bg-white outline-none" style={{ borderColor: "#E2E2E2" }}>{["Moto", "Carro", "Bicicleta"].map((v) => <option key={v}>{v}</option>)}</select>
              </div>
            </div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>E-mail (opcional)</label>
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <Btn className="w-full mt-1" icon={Check} onClick={salvar}>Cadastrar e ativar</Btn>
          </Card>
        </div>
      )}
    </Section>
  );
}

function Clientes({ toast }) {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("customers").select("*").eq("storeId", STORE_ID).order("name");
    if (error) toast("Erro ao carregar: " + error.message); else setList(data || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const toggleCashback = async (c, v) => {
    setList((l) => l.map((x) => x.id === c.id ? { ...x, cashbackEnabled: v } : x));
    const { error } = await supabase.from("customers").update({ cashbackEnabled: v }).eq("id", c.id);
    if (error) { toast("Erro: " + error.message); load(); }
  };
  const buscarCep = async (cep) => {
    const c = (cep || "").replace(/\D/g, "");
    if (c.length !== 8) return;
    try {
      const r = await fetch("https://viacep.com.br/ws/" + c + "/json/");
      const d = await r.json();
      if (!d.erro) setForm((f) => ({ ...f, logradouro: d.logradouro || "", bairro: d.bairro || "", cidade: d.localidade || "", uf: d.uf || "" }));
    } catch (e) {}
  };
  const salvar = async () => {
    if (!form.name) { toast("Informe o nome"); return; }
    const payload = { name: form.name, phone: form.phone, email: form.email || null, cep: form.cep || null, logradouro: form.logradouro || null, numero: form.numero || null, bairro: form.bairro || null, cidade: form.cidade || null, uf: form.uf || null };
    let error;
    if (form.id) ({ error } = await supabase.from("customers").update(payload).eq("id", form.id));
    else ({ error } = await supabase.from("customers").insert({ ...payload, storeId: STORE_ID, cashbackEnabled: true }));
    if (error) return toast("Erro: " + error.message);
    toast(form.id ? "Cliente atualizado" : "Cliente cadastrado"); setForm(null); load();
  };
  const excluir = async (c) => {
    if (!window.confirm("Excluir \"" + c.name + "\"? Esta ação remove do banco.")) return;
    const { error } = await supabase.from("customers").delete().eq("id", c.id);
    if (error) return toast("Erro: " + error.message);
    toast("Cliente excluído"); load();
  };

  return (
    <Section title="Clientes & cashback" desc="Cadastro real no banco — adicione, edite, exclua e ative o cashback por cliente."
      right={<Btn icon={Plus} onClick={() => setForm({ name: "", phone: "", email: "", cep: "", logradouro: "", numero: "", bairro: "", cidade: "", uf: "" })}>Novo cliente</Btn>}>
      {loading ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Carregando...</p> : (
        <Card className="p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr style={{ background: CREAM }}>{["Cliente", "Telefone", "Zips", "Total gasto", "Cashback", ""].map((h) => <th key={h} className="text-left px-4 py-3 font-semibold" style={{ color: NAVY }}>{h}</th>)}</tr></thead>
              <tbody>
                {list.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center" style={{ color: "#9AA0A6" }}>Nenhum cliente. Clique em "Novo cliente".</td></tr>}
                {list.map((c) => (
                  <tr key={c.id} className="border-t" style={{ borderColor: "#F0F0F0" }}>
                    <td className="px-4 py-3 font-medium" style={{ color: NAVY }}>{c.name}</td>
                    <td className="px-4 py-3" style={{ color: "#4B5563" }}>{c.phone || "—"}</td>
                    <td className="px-4 py-3"><span className="font-semibold" style={{ color: ORANGE }}>{Number(c.zips)}</span></td>
                    <td className="px-4 py-3" style={{ color: "#4B5563" }}>{money(Number(c.totalSpent))}</td>
                    <td className="px-4 py-3"><Toggle on={c.cashbackEnabled} onChange={(v) => toggleCashback(c, v)} /></td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button onClick={() => setForm({ id: c.id, name: c.name, phone: c.phone || "", email: c.email || "", cep: c.cep || "", logradouro: c.logradouro || "", numero: c.numero || "", bairro: c.bairro || "", cidade: c.cidade || "", uf: c.uf || "" })} className="text-sm font-semibold mr-3" style={{ color: NAVY }}>Editar</button>
                      <button onClick={() => excluir(c)} className="text-sm font-semibold" style={{ color: "#C0392B" }}>Excluir</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
      {form && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>{form.id ? "Editar cliente" : "Novo cliente"}</h3><button onClick={() => setForm(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Nome</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <label className="text-sm font-medium" style={{ color: NAVY }}>Telefone</label>
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <label className="text-sm font-medium" style={{ color: NAVY }}>E-mail</label>
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} type="email" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <div className="grid grid-cols-3 gap-2">
              <div className="col-span-2"><label className="text-sm font-medium" style={{ color: NAVY }}>CEP</label><input value={form.cep} onChange={(e) => setForm({ ...form, cep: e.target.value })} onBlur={(e) => buscarCep(e.target.value)} placeholder="00000-000" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Nº</label><input value={form.numero} onChange={(e) => setForm({ ...form, numero: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
            </div>
            <input value={form.logradouro} readOnly placeholder="Rua (preenche pelo CEP)" className="w-full mb-2 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#EEE", background: "#FAFAFA", color: "#4B5563" }} />
            <div className="grid grid-cols-3 gap-2 mb-3">
              <input value={form.bairro} readOnly placeholder="Bairro" className="col-span-1 px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "#EEE", background: "#FAFAFA", color: "#4B5563" }} />
              <input value={form.cidade} readOnly placeholder="Cidade" className="col-span-1 px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "#EEE", background: "#FAFAFA", color: "#4B5563" }} />
              <input value={form.uf} readOnly placeholder="UF" className="col-span-1 px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "#EEE", background: "#FAFAFA", color: "#4B5563" }} />
            </div>
            <Btn className="w-full mt-1" icon={Check} onClick={salvar}>{form.id ? "Salvar alterações" : "Cadastrar"}</Btn>
          </Card>
        </div>
      )}
    </Section>
  );
}

function Clube({ toast }) {
  const [ativo, setAtivo] = useState(true);
  const [pct, setPct] = useState(5);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("store_settings").select("*").eq("storeId", STORE_ID).maybeSingle();
      if (data) { setAtivo(data.cashbackEnabled); setPct(Number(data.cashbackPercent)); }
      setLoading(false);
    })();
  }, []);
  const salvar = async () => {
    const { error } = await supabase.from("store_settings").upsert({ storeId: STORE_ID, cashbackEnabled: ativo, cashbackPercent: pct, updatedAt: new Date().toISOString() }, { onConflict: "storeId" });
    if (error) return toast("Erro: " + error.message);
    toast("Configuração de cashback salva");
  };
  return (
    <Section title="Clube de pontos" desc="Cashback 100% configurável — defina a regra e salve." right={<Btn icon={Check} onClick={salvar} disabled={loading}>Salvar</Btn>}>
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-6">
          <div className="flex items-center justify-between"><div className="flex items-center gap-2"><Gift size={18} color={ORANGE} /><span className="font-bold" style={{ color: NAVY }}>Clube Zip ativo</span></div><Toggle on={ativo} onChange={setAtivo} /></div>
          <p className="text-sm mt-2" style={{ color: "#6B7280" }}>Os pontos do clube se chamam <b style={{ color: ORANGE }}>Zips</b>. 1 Zip = R$ 1 em compras futuras.</p>
          <div className="mt-6"><label className="text-sm font-medium" style={{ color: NAVY }}>Cashback por compra: <b style={{ color: ORANGE }}>{pct}%</b></label>
            <input type="range" min="0" max="20" value={pct} onChange={(e) => setPct(+e.target.value)} className="w-full mt-2" style={{ accentColor: ORANGE }} />
          </div>
          <Btn className="w-full mt-5" icon={Check} onClick={salvar} disabled={loading}>Salvar configuração</Btn>
        </Card>
        <Card className="p-6">
          <h3 className="font-bold mb-3" style={{ color: NAVY }}>Simulação</h3>
          {[["Compra de R$ 100", money(100 * pct / 100) + " em Zips"], ["Compra de R$ 250", money(250 * pct / 100) + " em Zips"], ["Cliente com 540 Zips", "R$ 540 disponíveis"]].map((r) => (
            <div key={r[0]} className="flex items-center justify-between py-2 border-b" style={{ borderColor: "#F2F2F2" }}><span className="text-sm" style={{ color: "#4B5563" }}>{r[0]}</span><span className="font-semibold text-sm" style={{ color: NAVY }}>{r[1]}</span></div>
          ))}
          <p className="text-xs mt-3" style={{ color: "#9AA0A6" }}>{ativo ? "Clube ativo a " + pct + "% por compra." : "Clube desativado."}</p>
        </Card>
      </div>
    </Section>
  );
}

function Pagamentos({ toast }) {
  const [registers, setRegisters] = useState([]);
  const [form, setForm] = useState(null);
  const load = async () => { const { data } = await supabase.from("registers").select("*").eq("storeId", STORE_ID).order("createdAt"); setRegisters(data || []); };
  useEffect(() => { load(); }, []);
  const salvarPdv = async () => { if (!form.name) return toast("Informe o nome do PDV"); const { error } = await supabase.from("registers").insert({ id: crypto.randomUUID(), storeId: STORE_ID, name: form.name, location: form.location || null, status: "offline" }); if (error) return toast("Erro: " + error.message); toast("PDV cadastrado"); setForm(null); load(); };
  const toggleStatus = async (r) => { const ns = r.status === "online" ? "offline" : "online"; setRegisters((l) => l.map((x) => x.id === r.id ? { ...x, status: ns } : x)); await supabase.from("registers").update({ status: ns }).eq("id", r.id); };
  const excluir = async (r) => { if (!window.confirm("Excluir " + r.name + "?")) return; await supabase.from("registers").delete().eq("id", r.id); toast("PDV removido"); load(); };
  return (
    <Section title="Pagamentos & PDVs" desc="Caixas (PDVs) da loja e meios de pagamento.">
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2"><Wallet size={18} color={ORANGE} /><span className="font-bold" style={{ color: NAVY }}>Mercado Pago (Pix + cartão)</span></div><Pill tone="gray">Configurar no servidor</Pill></div>
          <p className="text-sm" style={{ color: "#6B7280" }}>Por segurança, a chave secreta do Mercado Pago fica no servidor de pagamento — não no navegador. Com o servidor no ar, o Pix e o cartão online ficam ativos no checkout do cliente.</p>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-3"><CreditCard size={18} color={ORANGE} /><span className="font-bold" style={{ color: NAVY }}>Maquineta local</span></div>
          <p className="text-sm" style={{ color: "#6B7280" }}>Cartão presencial (crédito, débito e Pix no balcão) pela maquineta, integrada no app do caixa.</p>
        </Card>
      </div>
      <Card className="p-5">
        <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>PDVs (caixas) cadastrados</h3><Btn size="sm" variant="ghost" icon={Plus} onClick={() => setForm({ name: "", location: "" })}>Cadastrar PDV</Btn></div>
        {registers.length === 0 ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Nenhum PDV. Clique em "Cadastrar PDV".</p> : (
          <div className="grid md:grid-cols-3 gap-3">
            {registers.map((p) => (
              <div key={p.id} className="p-4 rounded-xl border" style={{ borderColor: "#ECECEC" }}>
                <div className="flex items-center gap-2 mb-2"><Store size={16} color={NAVY} /><span className="font-semibold text-sm" style={{ color: NAVY }}>{p.name}</span></div>
                <div className="text-sm" style={{ color: "#9AA0A6" }}>{p.location || "—"}</div>
                <div className="mt-2 flex items-center justify-between"><button onClick={() => toggleStatus(p)}><Pill tone={p.status === "online" ? "green" : "gray"}>{p.status === "online" ? "Online" : "Offline"}</Pill></button><button onClick={() => excluir(p)} style={{ color: "#C0392B" }}><X size={14} /></button></div>
              </div>
            ))}
          </div>
        )}
      </Card>
      {form && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>Cadastrar PDV</h3><button onClick={() => setForm(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Nome do caixa</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex.: Caixa 1" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <label className="text-sm font-medium" style={{ color: NAVY }}>Local</label>
            <input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Ex.: Balcão da frente" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <Btn className="w-full mt-1" icon={Check} onClick={salvarPdv}>Cadastrar</Btn>
          </Card>
        </div>
      )}
    </Section>
  );
}

function Whats({ toast }) {
  const [auto, setAuto] = useState(true);
  const fila = [
    { c: "Camila R.", msg: "1 pizza calabresa + Coca 2L", t: "há 2 min" },
    { c: "João P.", msg: "2 Zip Burger + batata", t: "há 5 min" },
    { c: "Lúcia M.", msg: "Encomenda: bolo 1kg p/ sábado", t: "há 9 min" },
  ];
  return (
    <Section title="Pedidos por WhatsApp" desc="Os pedidos chegam do WhatsApp direto para a cozinha, com resposta automática.">
      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-2"><MessageCircle size={18} color="#1B7F4B" /><span className="font-bold" style={{ color: NAVY }}>Conta conectada</span></div>
          <Pill tone="green">+55 11 99999-0000 · ativo</Pill>
          <div className="flex items-center justify-between mt-5"><span className="text-sm" style={{ color: NAVY }}>Resposta automática</span><Toggle on={auto} onChange={setAuto} /></div>
          <p className="text-xs mt-2" style={{ color: "#9AA0A6" }}>Confirma o pedido e envia o link de pagamento sozinho.</p>
        </Card>
        <Card className="p-5 lg:col-span-2">
          <h3 className="font-bold mb-3" style={{ color: NAVY }}>Fila de pedidos recebidos</h3>
          <div className="space-y-2">
            {fila.map((f) => (
              <div key={f.c} className="flex items-center justify-between p-3 rounded-xl" style={{ background: "#FAFAFA" }}>
                <div><div className="font-semibold text-sm" style={{ color: NAVY }}>{f.c}</div><div className="text-sm" style={{ color: "#6B7280" }}>{f.msg}</div></div>
                <div className="flex items-center gap-2"><span className="text-xs" style={{ color: "#9AA0A6" }}>{f.t}</span><Btn size="sm" onClick={() => toast("Pedido de " + f.c + " enviado à cozinha")}>Aceitar</Btn></div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </Section>
  );
}

const TENANT_ID = "cmq05qwp40000j5kvyxvr9ldv";
const ROLE_OPTS = [["MANAGER", "Gerente"], ["OPERATOR", "Operador de caixa"], ["BAKER", "Cozinha / Padeiro"], ["COURIER", "Entregador"], ["TENANT_ADMIN", "Administrador"]];
const roleLabel = (r) => (ROLE_OPTS.find((x) => x[0] === r) || [r, r])[1];
function Usuarios({ toast }) {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const load = async () => { setLoading(true); const { data, error } = await supabase.from("users").select("*").eq("tenantId", TENANT_ID).neq("role", "CUSTOMER").order("createdAt", { ascending: false }); if (error) toast("Erro: " + error.message); else setList(data || []); setLoading(false); };
  useEffect(() => { load(); }, []);
  const salvar = async () => {
    if (!form.name) return toast("Informe o nome");
    if (form.id) { const { error } = await supabase.from("users").update({ name: form.name, email: form.email || null, phone: form.phone || null, role: form.role, updatedAt: new Date().toISOString() }).eq("id", form.id); if (error) return toast("Erro: " + error.message); toast("Usuário atualizado"); }
    else { const { error } = await supabase.from("users").insert({ id: crypto.randomUUID(), tenantId: TENANT_ID, name: form.name, email: form.email || null, phone: form.phone || null, role: form.role, updatedAt: new Date().toISOString() }); if (error) return toast("Erro: " + error.message); toast("Usuário cadastrado"); }
    setForm(null); load();
  };
  const excluir = async (u) => { if (!window.confirm("Excluir " + u.name + "?")) return; const { error } = await supabase.from("users").delete().eq("id", u.id); if (error) return toast("Erro: " + error.message); toast("Usuário removido"); load(); };
  return (
    <Section title="Usuários & permissões" desc="Equipe com papéis e níveis de acesso — gravado no banco." right={<Btn icon={Plus} onClick={() => setForm({ name: "", email: "", phone: "", role: "OPERATOR" })}>Novo usuário</Btn>}>
      {loading ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Carregando...</p> : (
        <Card className="p-0 overflow-hidden">
          <table className="w-full text-sm">
            <thead><tr style={{ background: CREAM }}>{["Usuário", "Papel", "Contato", ""].map((h) => <th key={h} className="text-left px-4 py-3 font-semibold" style={{ color: NAVY }}>{h}</th>)}</tr></thead>
            <tbody>
              {list.length === 0 && <tr><td colSpan={4} className="px-4 py-8 text-center" style={{ color: "#9AA0A6" }}>Nenhum usuário da equipe ainda.</td></tr>}
              {list.map((u) => (
                <tr key={u.id} className="border-t" style={{ borderColor: "#F0F0F0" }}>
                  <td className="px-4 py-3 font-medium" style={{ color: NAVY }}>{u.name}</td>
                  <td className="px-4 py-3"><Pill tone="navy">{roleLabel(u.role)}</Pill></td>
                  <td className="px-4 py-3" style={{ color: "#4B5563" }}>{u.email || u.phone || "—"}</td>
                  <td className="px-4 py-3 text-right whitespace-nowrap"><button onClick={() => setForm({ id: u.id, name: u.name, email: u.email || "", phone: u.phone || "", role: u.role })} className="text-sm font-semibold mr-3" style={{ color: NAVY }}>Editar</button><button onClick={() => excluir(u)} className="text-sm font-semibold" style={{ color: "#C0392B" }}>Excluir</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
      {form && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>{form.id ? "Editar usuário" : "Novo usuário"}</h3><button onClick={() => setForm(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Nome</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <label className="text-sm font-medium" style={{ color: NAVY }}>Papel</label>
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm bg-white outline-none" style={{ borderColor: "#E2E2E2" }}>{ROLE_OPTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>E-mail</label><input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Telefone</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
            </div>
            <Btn className="w-full mt-1" icon={Check} onClick={salvar}>{form.id ? "Salvar" : "Cadastrar"}</Btn>
          </Card>
        </div>
      )}
    </Section>
  );
}

const SNIPPETS = [
  { t: "Mercado Pago — criar cobrança (Pix/cartão) · Node", c:
"// Backend Node — pacote npm: mercadopago\n// const { MercadoPagoConfig, Preference } = mp_sdk\nconst mp = new MercadoPagoConfig({ accessToken: process.env.MP_TOKEN });\n\nexport async function criarPagamento(req, res) {\n  const pref = await new Preference(mp).create({ body: {\n    items: req.body.itens, // [{ title, quantity, unit_price }]\n    notification_url: 'https://api.zipao.com.br/webhooks/mp',\n    back_urls: { success: 'https://zipao.com.br/ok' },\n  }});\n  res.json({ init_point: pref.init_point, qr: pref.point_of_interaction });\n}" },
  { t: "WhatsApp Cloud API — receber pedido (webhook) · Node", c:
"// POST /webhooks/whatsapp  — a Meta envia cada mensagem aqui\nexport async function whatsappWebhook(req, res) {\n  const msg = req.body.entry?.[0]?.changes?.[0]?.value?.messages?.[0];\n  if (msg) {\n    await Pedido.create({ canal: 'whatsapp', de: msg.from, texto: msg.text?.body });\n    await enviarResposta(msg.from, 'Recebemos seu pedido! Pague aqui: ' + link);\n  }\n  res.sendStatus(200);\n}" },
  { t: "Entrada de NF-e — ler XML e lançar no estoque · Node", c:
"// Backend Node — pacote npm: fast-xml-parser\n// const parser = new XMLParser()\nexport function importarNFe(xml) {\n  const nfe = parser.parse(xml);\n  const itens = [].concat(nfe.nfeProc.NFe.infNFe.det);\n  for (const det of itens) {\n    const p = det.prod;\n    estoque.entrada({ nome: p.xProd, qtd: Number(p.qCom), custo: Number(p.vUnCom) });\n  }\n}" },
  { t: "NFC-e — emitir e mandar para a impressora fiscal · Node", c:
"// Backend Node — pacote npm: node-nfe (ou ACBr / PlugNotas)\nexport async function emitirNFCe(venda) {\n  const nota = await NFe.emitir({ modelo: '65', itens: venda.itens,\n    pagamentos: venda.pagamentos, certificado: process.env.CERT_A1 });\n  await impressoraFiscal.imprimir(nota.danfceXml); // ESC/POS\n  return nota.chave;\n}" },
];
function Integracoes() {
  return (
    <Section title="Integrações (código para plugar)" desc="Snippets prontos para o servidor. Copie para a sua API e preencha as credenciais.">
      <div className="grid lg:grid-cols-2 gap-4">
        {SNIPPETS.map((s) => (
          <Card key={s.t} className="p-0 overflow-hidden">
            <div className="flex items-center gap-2 px-4 py-3" style={{ background: NAVY }}><Plug size={16} color={ORANGE} /><span className="text-sm font-semibold text-white">{s.t}</span></div>
            <pre className="text-xs p-4 overflow-x-auto" style={{ color: "#E6E6E6", background: "#11151F", margin: 0, lineHeight: 1.5 }}><code>{s.c}</code></pre>
          </Card>
        ))}
      </div>
      <Card className="p-5 mt-4" style={{ background: SOFT, borderColor: ORANGE }}>
        <div className="flex items-start gap-3"><AlertTriangle size={18} color={ORANGE} className="mt-0.5" />
          <p className="text-sm" style={{ color: NAVY }}>Estas integrações rodam no <b>servidor (backend)</b>, não no navegador — exigem credenciais reais (token do Mercado Pago, certificado A1, número aprovado no WhatsApp Business e driver da impressora). A interface acima já está pronta para consumir essas rotas.</p>
        </div>
      </Card>
    </Section>
  );
}

function Relatorios() {
  return (
    <Section title="Relatórios" desc="Desempenho por período, unidade e forma de pagamento.">
      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-5"><h3 className="font-bold mb-3" style={{ color: NAVY }}>Faturamento na semana</h3>
          <ResponsiveContainer width="100%" height={220}><BarChart data={vendasSemana}><CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" vertical={false} /><XAxis dataKey="d" tick={{ fontSize: 12, fill: "#9AA0A6" }} axisLine={false} tickLine={false} /><YAxis tick={{ fontSize: 12, fill: "#9AA0A6" }} axisLine={false} tickLine={false} width={50} /><Tooltip formatter={(v) => money(v)} /><Bar dataKey="v" fill={ORANGE} radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer>
        </Card>
        <Card className="p-5"><h3 className="font-bold mb-3" style={{ color: NAVY }}>Formas de pagamento</h3>
          {[["Pix (Mercado Pago)", 42], ["Cartão maquineta", 31], ["Cartão online", 18], ["Dinheiro", 9]].map((r) => (
            <div key={r[0]} className="mb-3"><div className="flex justify-between text-sm mb-1"><span style={{ color: NAVY }}>{r[0]}</span><span style={{ color: "#6B7280" }}>{r[1]}%</span></div>
              <div className="h-2 rounded-full" style={{ background: "#F0F0F0" }}><div className="h-2 rounded-full" style={{ width: r[1] + "%", background: ORANGE }} /></div></div>
          ))}
        </Card>
      </div>
    </Section>
  );
}

function Cardapio({ toast }) {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null); // {id?, name, price, categoryId, available}
  const catName = (id) => (CATEGORIAS.find((c) => c.id === id) || {}).name || "—";

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("products").select("*").eq("storeId", STORE_ID).order("name");
    if (error) toast("Erro ao carregar: " + error.message); else setList(data || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const novo = () => setForm({ name: "", price: "", categoryId: CATEGORIAS[0].id, available: true });
  const salvar = async () => {
    if (!form.name || form.price === "") { toast("Preencha nome e preço"); return; }
    if (form.id) {
      const { error } = await supabase.from("products").update({
        name: form.name, price: Number(form.price), categoryId: form.categoryId, available: form.available, updatedAt: new Date().toISOString(),
      }).eq("id", form.id);
      if (error) return toast("Erro: " + error.message);
      toast("Produto atualizado");
    } else {
      const { error } = await supabase.from("products").insert({
        id: crypto.randomUUID(), storeId: STORE_ID, name: form.name, slug: slugify(form.name),
        price: Number(form.price), categoryId: form.categoryId, available: form.available,
        type: "STOCK", order: 0, updatedAt: new Date().toISOString(),
      });
      if (error) return toast("Erro: " + error.message);
      toast("Produto cadastrado");
    }
    setForm(null); load();
  };
  const excluir = async (p) => {
    if (!window.confirm("Excluir \"" + p.name + "\"? Esta ação remove do banco.")) return;
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) return toast("Erro: " + error.message);
    toast("Produto excluído"); load();
  };

  return (
    <Section title="Produtos & cardápio" desc="Cadastro real no banco — adicione, edite e exclua itens."
      right={<Btn icon={Plus} onClick={novo}>Novo produto</Btn>}>
      {loading ? <p className="text-sm" style={{ color: "#9AA0A6" }}>Carregando...</p> : (
        <Card className="p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr style={{ background: CREAM }}>{["Produto", "Categoria", "Preço", "Disponível", ""].map((h) => <th key={h} className="text-left px-4 py-3 font-semibold" style={{ color: NAVY }}>{h}</th>)}</tr></thead>
              <tbody>
                {list.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center" style={{ color: "#9AA0A6" }}>Nenhum produto. Clique em "Novo produto".</td></tr>}
                {list.map((p) => (
                  <tr key={p.id} className="border-t" style={{ borderColor: "#F0F0F0" }}>
                    <td className="px-4 py-3 font-medium" style={{ color: NAVY }}>{p.name}</td>
                    <td className="px-4 py-3" style={{ color: "#4B5563" }}>{catName(p.categoryId)}</td>
                    <td className="px-4 py-3" style={{ color: ORANGE }}>{money(Number(p.price))}</td>
                    <td className="px-4 py-3">{p.available ? <Pill tone="green">Sim</Pill> : <Pill tone="gray">Não</Pill>}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button onClick={() => setForm({ id: p.id, name: p.name, price: String(p.price), categoryId: p.categoryId || CATEGORIAS[0].id, available: p.available })} className="text-sm font-semibold mr-3" style={{ color: NAVY }}>Editar</button>
                      <button onClick={() => excluir(p)} className="text-sm font-semibold" style={{ color: "#C0392B" }}>Excluir</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
      {form && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{ color: NAVY }}>{form.id ? "Editar produto" : "Novo produto"}</h3><button onClick={() => setForm(null)}><X size={20} color="#9AA0A6" /></button></div>
            <label className="text-sm font-medium" style={{ color: NAVY }}>Nome</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Preço (R$)</label><input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} type="number" step="0.01" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} /></div>
              <div><label className="text-sm font-medium" style={{ color: NAVY }}>Categoria</label>
                <select value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })} className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none bg-white" style={{ borderColor: "#E2E2E2" }}>
                  {CATEGORIAS.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
            </div>
            <label className="flex items-center justify-between py-2"><span className="text-sm font-medium" style={{ color: NAVY }}>Disponível</span><Toggle on={form.available} onChange={(v) => setForm({ ...form, available: v })} /></label>
            <Btn className="w-full mt-3" icon={Check} onClick={salvar}>{form.id ? "Salvar alterações" : "Cadastrar"}</Btn>
          </Card>
        </div>
      )}
    </Section>
  );
}

/* ============================ Área do cliente ============================ */
const LOJA_NOME = "Padaria Zipão Demo — Centro";
const PED_LABEL = { novo: "Pedido enviado", aceito: "Pedido aceito", producao: "Preparando seu pedido", pronto: "Pedido pronto", coletado: "Entregador coletou o pedido", entrega: "Saiu para entrega", entregue: "Pedido entregue" };
const PED_FLOW_ENTREGA = ["novo", "aceito", "producao", "pronto", "coletado", "entrega", "entregue"];
const PED_FLOW_RETIRADA = ["novo", "aceito", "producao", "pronto", "entregue"];
const normPedStatus = (s) => ({ Recebido: "novo", novo: "novo", aceito: "aceito", "Em produção": "producao", producao: "producao", Pronto: "pronto", pronto: "pronto", coletado: "coletado", entrega: "entrega", "Saiu para entrega": "entrega", entregue: "entregue", Entregue: "entregue", concluido: "entregue" }[s] || "novo");

function AcompanharPedido({ done, onNovo, onExit }) {
  const [status, setStatus] = useState("novo");
  useEffect(() => {
    let alive = true;
    const fetchSt = async () => { try { const { data } = await supabase.from("pedidos").select("status").eq("id", done.id).single(); if (alive && data) setStatus(normPedStatus(data.status)); } catch (e) {} };
    fetchSt(); const t = setInterval(fetchSt, 5000); return () => { alive = false; clearInterval(t); };
  }, [done.id]);
  const flow = done.tipo === "entrega" ? PED_FLOW_ENTREGA : PED_FLOW_RETIRADA;
  const idx = Math.max(0, flow.indexOf(status));
  const entregue = status === "entregue";
  return (
    <div className="min-h-screen" style={{ background: CREAM }}>
      <header style={{ background: NAVY }}><div className="max-w-md mx-auto px-4 py-3 flex items-center gap-2"><ZipIcon size={32} /><div className="text-white font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>{LOJA_NOME}</div></div></header>
      <div className="max-w-md mx-auto p-4">
        <Card className="p-6">
          <div className="text-center mb-5">
            <div className="h-14 w-14 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: SOFT }}>{entregue ? <Check size={28} color={ORANGE} /> : <Clock size={26} color={ORANGE} />}</div>
            <h2 className="text-xl font-bold" style={{ color: NAVY }}>{entregue ? "Você recebeu seu pedido!" : "Acompanhe seu pedido"}</h2>
            <p className="text-sm mt-1" style={{ color: "#6B7280" }}>Pedido #{done.num} · {money(done.total)}</p>
          </div>
          <div>
            {flow.map((s, i) => { const dn = i < idx, cur = i === idx; return (
              <div key={s} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="h-8 w-8 rounded-full flex items-center justify-center" style={{ background: (dn || cur) ? ORANGE : "#E5E7EB", color: "#fff" }}>{dn ? <Check size={16} /> : cur ? <Clock size={15} /> : <span className="text-xs font-bold">{i + 1}</span>}</div>
                  {i < flow.length - 1 && <div style={{ width: 2, height: 26, background: dn ? ORANGE : "#E5E7EB" }} />}
                </div>
                <div className="pb-4 pt-1"><div className="text-sm font-semibold" style={{ color: (dn || cur) ? NAVY : "#9AA0A6" }}>{PED_LABEL[s]}</div>{cur && !entregue && <div className="text-xs" style={{ color: ORANGE }}>Em andamento…</div>}</div>
              </div>
            ); })}
          </div>
          <Btn className="w-full mt-2" onClick={onNovo}>Fazer novo pedido</Btn>
          <button onClick={onExit} className="w-full mt-2 text-sm font-semibold" style={{ color: "#6B7280" }}>Sair</button>
        </Card>
        <p className="text-xs text-center mt-3" style={{ color: "#9AA0A6" }}>Esta tela atualiza sozinha conforme a loja prepara seu pedido.</p>
      </div>
    </div>
  );
}
const EXTRAS_SUG = [{ n: "Bacon extra", p: 4 }, { n: "Refrigerante lata", p: 6 }, { n: "Porção de batata", p: 9 }, { n: "Sobremesa do dia", p: 8 }];

function ClienteApp({ onExit, toast }) {
  const [tab, setTab] = useState("cardapio");
  const [cart, setCart] = useState([]);
  const [sel, setSel] = useState(null);
  const [qty, setQty] = useState(1);
  const [obs, setObs] = useState("");
  const [extras, setExtras] = useState([]);
  const [done, setDone] = useState(null);
  const [co, setCo] = useState({ tipo: "entrega", nome: "", tel: "", cep: "", rua: "", num: "", comp: "", bairro: "", cidade: "", uf: "", pagamento: "Pix" });
  const [enc, setEnc] = useState({ item: "", quando: "", obs: "", nome: "", tel: "" });
  const [encDone, setEncDone] = useState(false);

  const [cats, setCats] = useState([]);
  const [loadingMenu, setLoadingMenu] = useState(true);
  useEffect(() => {
    (async () => {
      const rc = await supabase.from("product_categories").select("*").eq("storeId", STORE_ID).order("order");
      const rp = await supabase.from("products").select("id,name,price,categoryId,imageUrl,description,available").eq("storeId", STORE_ID).order("order");
      const prods = (rp.data || []).filter((p) => p.available !== false);
      const categs = rc.data || [];
      let grouped = categs.map((c) => ({ id: c.id, name: c.name, produtos: prods.filter((p) => p.categoryId === c.id) })).filter((g) => g.produtos.length);
      const semCat = prods.filter((p) => !categs.find((c) => c.id === p.categoryId));
      if (semCat.length) grouped.push({ id: "_outros", name: "Outros", produtos: semCat });
      if (grouped.length === 0 && prods.length) grouped = [{ id: "_all", name: "Cardápio", produtos: prods }];
      setCats(grouped);
      setLoadingMenu(false);
    })();
  }, []);
  const PALETA = ["#E8590C", "#C0392B", "#8B5E34", "#D35400", "#2E7D32", "#1565C0", "#C2185B", "#B8860B"];
  const catCor = (id) => PALETA[Math.abs(String(id).split("").reduce((a, c) => a + c.charCodeAt(0), 0)) % PALETA.length];
  const itemTotal = (x) => (x.p + x.extras.reduce((s, e) => s + e.p, 0)) * x.q;
  const total = cart.reduce((s, x) => s + itemTotal(x), 0);
  const count = cart.reduce((s, x) => s + x.q, 0);

  const abrir = (p, catId) => { setSel({ p, catId }); setQty(1); setObs(""); setExtras([]); };
  const addCart = () => { setCart((c) => [...c, { key: Date.now(), productId: sel.p.id, n: sel.p.name, p: Number(sel.p.price), catId: sel.catId, q: qty, obs, extras }]); toast(qty + "× " + sel.p.name + " no carrinho"); setSel(null); };
  const toggleExtra = (e) => setExtras((arr) => arr.find((x) => x.n === e.n) ? arr.filter((x) => x.n !== e.n) : [...arr, e]);
  const removeItem = (key) => setCart((c) => c.filter((x) => x.key !== key));
  const buscarCep = async (cep) => { const c = (cep || "").replace(/\D/g, ""); if (c.length !== 8) return; try { const r = await fetch("https://viacep.com.br/ws/" + c + "/json/"); const d = await r.json(); if (!d.erro) setCo((s) => ({ ...s, rua: d.logradouro || "", bairro: d.bairro || "", cidade: d.localidade || "", uf: d.uf || "" })); } catch (e) {} };
  const finalizar = async () => {
    if (cart.length === 0) return toast("Carrinho vazio");
    if (!co.nome || !co.tel) return toast("Informe nome e telefone");
    if (co.tipo === "entrega" && !co.cep) return toast("Informe o endereço de entrega");
    const endereco = co.tipo === "entrega" ? (co.rua + ", " + co.num + (co.comp ? " - " + co.comp : "") + " - " + co.bairro + ", " + co.cidade + "/" + co.uf) : "Retirada na loja";
    const itens = cart.map((x) => ({ productId: x.productId, nome: x.n, qtd: x.q, preco: x.p, extras: x.extras.map((e) => e.n), obs: x.obs }));
    const { data, error } = await supabase.from("pedidos").insert({ storeId: STORE_ID, tipo: co.tipo, cliente: co.nome, telefone: co.tel, endereco, itens, total, pagamento: co.pagamento, status: "novo" }).select("id").single();
    if (error) return toast("Erro: " + error.message);
    setDone({ id: data.id, num: String(data.id).replace(/-/g, "").slice(0, 4).toUpperCase(), total, tipo: co.tipo, endereco, pagamento: co.pagamento }); setCart([]);
  };
  const enviarEncomenda = async () => {
    if (!enc.item || !enc.nome) return toast("Informe o item e seu nome");
    const { error } = await supabase.from("encomendas").insert({ storeId: STORE_ID, cliente: enc.nome + (enc.tel ? " (" + enc.tel + ")" : ""), item: enc.item + (enc.obs ? " — " + enc.obs : ""), quando: enc.quando ? new Date(enc.quando).toISOString() : null, status: "Aguardando pagamento", valor: 0 });
    if (error) return toast("Erro: " + error.message);
    setEncDone(true); setEnc({ item: "", quando: "", obs: "", nome: "", tel: "" });
  };

  if (done) {
    return <AcompanharPedido done={done} onNovo={() => { setDone(null); setTab("cardapio"); }} onExit={onExit} />;
  }

  const tabs = [["cardapio", "Cardápio", Utensils], ["pedido", "Carrinho", ShoppingCart], ["encomenda", "Encomenda", Calendar], ["clube", "Zips", Gift]];
  return (
    <div className="min-h-screen" style={{ background: CREAM }}>
      <header style={{ background: NAVY }}>
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2"><ZipIcon size={34} /><div><div className="text-white font-bold leading-tight" style={{ fontFamily: "Fredoka, sans-serif" }}>{LOJA_NOME}</div><div className="text-white/60 text-xs">Aberto agora · entrega e retirada</div></div></div>
          <button onClick={onExit} className="text-white/80 text-sm inline-flex items-center gap-1"><LogOut size={16} /></button>
        </div>
      </header>
      <div className="max-w-3xl mx-auto px-4">
        <div className="rounded-2xl mt-4 p-5 text-white" style={{ background: "linear-gradient(135deg," + ORANGE + ",#ff8a5c)" }}>
          <div className="font-bold text-lg">Peça e ganhe Zips de volta</div>
          <div className="text-sm text-white/90">Cashback em todo pedido · entrega rápida na sua casa.</div>
        </div>
      </div>
      <div className="max-w-3xl mx-auto p-4">
        <div className="flex gap-2 mb-4">
          {tabs.map(([k, l, I]) => <button key={k} onClick={() => setTab(k)} className="flex-1 py-2.5 rounded-xl text-sm font-semibold inline-flex items-center justify-center gap-2 relative" style={tab === k ? { background: ORANGE, color: "#fff" } : { background: "#fff", color: NAVY, border: "1px solid #E8E8E8" }}><I size={16} />{l}{k === "pedido" && count > 0 && <span className="absolute -top-1 -right-1 h-5 min-w-5 px-1 rounded-full text-xs font-bold flex items-center justify-center" style={{ background: NAVY, color: "#fff" }}>{count}</span>}</button>)}
        </div>

        {tab === "cardapio" && (
          loadingMenu ? <Card className="p-8 text-center"><span className="text-sm" style={{ color: "#9AA0A6" }}>Carregando cardápio...</span></Card>
          : cats.length === 0 ? <Card className="p-8 text-center"><span className="text-sm" style={{ color: "#9AA0A6" }}>O cardápio ainda não tem produtos. O dono cadastra em "Cardápio" no painel.</span></Card>
          : (
          <div className="space-y-6">
            {cats.map((u) => (
              <div key={u.id}>
                <div className="flex items-center gap-2 mb-2"><Utensils size={16} color={ORANGE} /><h3 className="font-bold" style={{ color: NAVY }}>{u.name}</h3></div>
                <div className="grid sm:grid-cols-2 gap-3">
                  {u.produtos.map((p) => (
                    <button key={p.id} onClick={() => abrir(p, u.id)} className="text-left bg-white rounded-2xl border overflow-hidden hover:shadow-md transition flex" style={{ borderColor: "#ECECEC" }}>
                      {p.imageUrl
                        ? <img src={p.imageUrl} alt={p.name} className="w-24 h-24 shrink-0 object-cover" />
                        : <div className="w-24 shrink-0 flex items-center justify-center" style={{ background: "linear-gradient(135deg," + catCor(u.id) + "," + catCor(u.id) + "bb)" }}><Utensils size={30} color="rgba(255,255,255,.92)" /></div>}
                      <div className="p-3 flex-1"><div className="font-semibold text-sm" style={{ color: NAVY }}>{p.name}</div><div className="text-xs mt-0.5" style={{ color: "#9AA0A6" }}>{p.description || "Toque para escolher"}</div><div className="text-sm mt-1 font-bold" style={{ color: ORANGE }}>{money(Number(p.price))}</div></div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          )
        )}

        {tab === "pedido" && (
          cart.length === 0 ? <Card className="p-8 text-center"><ShoppingCart size={28} color="#D6D8DD" className="mx-auto mb-2" /><p className="text-sm" style={{ color: "#9AA0A6" }}>Seu carrinho está vazio. Escolha no cardápio.</p></Card> : (
            <div className="space-y-4">
              <Card className="p-5">
                <h3 className="font-bold mb-3" style={{ color: NAVY }}>Seu pedido</h3>
                {cart.map((x) => (
                  <div key={x.key} className="flex items-start justify-between py-2 border-b" style={{ borderColor: "#F2F2F2" }}>
                    <div className="text-sm"><div className="font-medium" style={{ color: NAVY }}>{x.q}× {x.n}</div>
                      {x.extras.length > 0 && <div className="text-xs" style={{ color: "#9AA0A6" }}>+ {x.extras.map((e) => e.n).join(", ")}</div>}
                      {x.obs && <div className="text-xs italic" style={{ color: "#9AA0A6" }}>"{x.obs}"</div>}
                    </div>
                    <div className="flex items-center gap-2"><span className="text-sm font-semibold" style={{ color: NAVY }}>{money(itemTotal(x))}</span><button onClick={() => removeItem(x.key)} style={{ color: "#C0392B" }}><X size={14} /></button></div>
                  </div>
                ))}
                <div className="flex justify-between mt-3"><span className="font-bold" style={{ color: NAVY }}>Total</span><span className="font-bold text-lg" style={{ color: NAVY }}>{money(total)}</span></div>
              </Card>
              <Card className="p-5">
                <h3 className="font-bold mb-3" style={{ color: NAVY }}>Seus dados</h3>
                <div className="flex gap-2 mb-3">
                  {[["entrega", "Entrega"], ["retirada", "Retirada"]].map(([k, l]) => <button key={k} onClick={() => setCo({ ...co, tipo: k })} className="flex-1 py-2 rounded-xl text-sm font-semibold" style={co.tipo === k ? { background: NAVY, color: "#fff" } : { background: "#F4F4F5", color: NAVY }}>{l}</button>)}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input value={co.nome} onChange={(e) => setCo({ ...co, nome: e.target.value })} placeholder="Seu nome" className="px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                  <input value={co.tel} onChange={(e) => setCo({ ...co, tel: e.target.value })} placeholder="WhatsApp" className="px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                </div>
                {co.tipo === "entrega" && (
                  <div className="mt-2">
                    <div className="grid grid-cols-3 gap-2">
                      <input value={co.cep} onChange={(e) => setCo({ ...co, cep: e.target.value })} onBlur={(e) => buscarCep(e.target.value)} placeholder="CEP" className="col-span-2 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                      <input value={co.num} onChange={(e) => setCo({ ...co, num: e.target.value })} placeholder="Nº" className="px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                    </div>
                    <input value={co.rua} readOnly placeholder="Rua (pelo CEP)" className="w-full mt-2 px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "#EEE", background: "#FAFAFA", color: "#4B5563" }} />
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <input value={co.bairro} readOnly placeholder="Bairro" className="px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "#EEE", background: "#FAFAFA", color: "#4B5563" }} />
                      <input value={co.cidade} readOnly placeholder="Cidade" className="px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "#EEE", background: "#FAFAFA", color: "#4B5563" }} />
                      <input value={co.uf} readOnly placeholder="UF" className="px-3 py-2.5 rounded-xl border text-sm" style={{ borderColor: "#EEE", background: "#FAFAFA", color: "#4B5563" }} />
                    </div>
                    <input value={co.comp} onChange={(e) => setCo({ ...co, comp: e.target.value })} placeholder="Complemento (apto, bloco...)" className="w-full mt-2 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                  </div>
                )}
                <div className="text-sm font-semibold mt-4 mb-2" style={{ color: NAVY }}>Pagamento</div>
                <div className="grid grid-cols-2 gap-2">
                  {[["Pix", QrCode], ["Cartão na entrega", CreditCard], ["Dinheiro", Banknote], ["Usar Zips", Gift]].map(([l, I]) => <button key={l} onClick={() => setCo({ ...co, pagamento: l })} className="p-2.5 rounded-xl border inline-flex items-center gap-2 text-sm font-medium" style={co.pagamento === l ? { borderColor: ORANGE, background: SOFT, color: NAVY } : { borderColor: "#E2E2E2", color: NAVY }}><I size={15} color={ORANGE} />{l}</button>)}
                </div>
                <Btn className="w-full mt-4" icon={Check} onClick={finalizar}>Finalizar pedido · {money(total)}</Btn>
              </Card>
            </div>
          )
        )}

        {tab === "encomenda" && (
          encDone ? <Card className="p-8 text-center"><div className="h-14 w-14 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: SOFT }}><Check size={26} color={ORANGE} /></div><h3 className="font-bold" style={{ color: NAVY }}>Encomenda solicitada!</h3><p className="text-sm mt-1" style={{ color: "#6B7280" }}>{LOJA_NOME} vai confirmar com você.</p><Btn variant="ghost" className="mt-4" onClick={() => setEncDone(false)}>Fazer outra</Btn></Card>
            : <Card className="p-5">
              <h3 className="font-bold mb-1" style={{ color: NAVY }}>Fazer uma encomenda</h3>
              <p className="text-sm mb-4" style={{ color: "#6B7280" }}>Bolos, salgados para festa, pedidos especiais.</p>
              <label className="text-sm font-medium" style={{ color: NAVY }}>O que você quer encomendar?</label>
              <input value={enc.item} onChange={(e) => setEnc({ ...enc, item: e.target.value })} placeholder="Ex.: Bolo 2kg de chocolate" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
              <label className="text-sm font-medium" style={{ color: NAVY }}>Para quando?</label>
              <input value={enc.quando} onChange={(e) => setEnc({ ...enc, quando: e.target.value })} type="datetime-local" className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
              <label className="text-sm font-medium" style={{ color: NAVY }}>Detalhes</label>
              <input value={enc.obs} onChange={(e) => setEnc({ ...enc, obs: e.target.value })} placeholder="Recheio, escrita no bolo, etc." className="w-full mt-1 mb-3 px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
              <div className="grid grid-cols-2 gap-2">
                <input value={enc.nome} onChange={(e) => setEnc({ ...enc, nome: e.target.value })} placeholder="Seu nome" className="px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
                <input value={enc.tel} onChange={(e) => setEnc({ ...enc, tel: e.target.value })} placeholder="WhatsApp" className="px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
              </div>
              <Btn className="w-full mt-4" icon={Calendar} onClick={enviarEncomenda}>Solicitar encomenda</Btn>
            </Card>
        )}

        {tab === "clube" && (
          <Card className="p-6 text-center">
            <div className="h-14 w-14 rounded-2xl flex items-center justify-center mx-auto mb-3" style={{ background: SOFT }}><Gift size={26} color={ORANGE} /></div>
            <div className="text-sm" style={{ color: "#6B7280" }}>Seu saldo no Clube Zip</div>
            <div className="text-4xl font-bold my-1" style={{ color: NAVY }}>320 <span className="text-lg" style={{ color: ORANGE }}>Zips</span></div>
            <p className="text-sm" style={{ color: "#9AA0A6" }}>Equivale a {money(320)} em compras. Você ganha cashback a cada pedido.</p>
          </Card>
        )}
      </div>

      {sel && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4" style={{ background: "rgba(26,33,54,.55)" }}>
          <Card className="w-full sm:max-w-md p-0 overflow-hidden rounded-t-2xl sm:rounded-2xl">
            <div className="h-40 flex items-center justify-center relative" style={{ background: "linear-gradient(135deg," + catCor(sel.catId) + "," + catCor(sel.catId) + "bb)" }}>
              {sel.p.imageUrl ? <img src={sel.p.imageUrl} alt={sel.p.name} className="w-full h-full object-cover" /> : <Utensils size={56} color="rgba(255,255,255,.92)" />}
              <button onClick={() => setSel(null)} className="absolute top-3 right-3 h-8 w-8 rounded-full flex items-center justify-center" style={{ background: "rgba(0,0,0,.3)" }}><X size={18} color="#fff" /></button>
            </div>
            <div className="p-5">
              <div className="flex items-center justify-between"><h3 className="font-bold text-lg" style={{ color: NAVY }}>{sel.p.name}</h3><span className="font-bold" style={{ color: ORANGE }}>{money(Number(sel.p.price))}</span></div>
              <p className="text-sm mt-1" style={{ color: "#9AA0A6" }}>{sel.p.description || "Feito na hora. Personalize do seu jeito."}</p>
              <div className="mt-4"><div className="text-sm font-semibold mb-2" style={{ color: NAVY }}>Quer adicionar algo?</div>
                <div className="space-y-2">{EXTRAS_SUG.map((e) => { const on = extras.find((x) => x.n === e.n); return (
                  <button key={e.n} onClick={() => toggleExtra(e)} className="w-full flex items-center justify-between p-2.5 rounded-xl border text-sm" style={on ? { borderColor: ORANGE, background: SOFT } : { borderColor: "#E2E2E2" }}><span style={{ color: NAVY }}>{e.n}</span><span style={{ color: ORANGE }}>+{money(e.p)}</span></button>
                ); })}</div>
              </div>
              <div className="mt-4"><div className="text-sm font-semibold mb-1" style={{ color: NAVY }}>Observação</div>
                <input value={obs} onChange={(e) => setObs(e.target.value)} placeholder="Ex.: sem cebola, bem passado..." className="w-full px-3 py-2.5 rounded-xl border text-sm outline-none" style={{ borderColor: "#E2E2E2" }} />
              </div>
              <div className="flex items-center gap-4 mt-4">
                <div className="flex items-center gap-3">
                  <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="h-10 w-10 rounded-xl flex items-center justify-center" style={{ background: "#F1F2F4" }}><Minus size={18} /></button>
                  <span className="text-xl font-bold w-8 text-center" style={{ color: NAVY }}>{qty}</span>
                  <button onClick={() => setQty((q) => q + 1)} className="h-10 w-10 rounded-xl flex items-center justify-center" style={{ background: SOFT }}><Plus size={18} color={ORANGE} /></button>
                </div>
                <Btn className="flex-1" icon={ShoppingCart} onClick={addCart}>Adicionar {money((Number(sel.p.price) + extras.reduce((s, e) => s + e.p, 0)) * qty)}</Btn>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

/* ============================ Operação ao vivo (Cozinha / Pedidos / Entregador) ============================ */
let _audioCtx = null;
function unlockAudio() {
  if (!_audioCtx) { try { _audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} }
  if (_audioCtx && _audioCtx.state === "suspended") _audioCtx.resume();
}
function beep() {
  if (!_audioCtx) return;
  [0, 0.18].forEach((delay) => {
    const o = _audioCtx.createOscillator(), g = _audioCtx.createGain();
    o.connect(g); g.connect(_audioCtx.destination);
    o.type = "sine"; o.frequency.value = 880;
    const t = _audioCtx.currentTime + delay;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.3, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.15);
    o.start(t); o.stop(t + 0.16);
  });
}

const STORE_COORD = { lat: -23.5895, lng: -46.6347 };
function distKm(a, b) {
  const R = 6371, dLat = (b.lat - a.lat) * Math.PI / 180, dLng = (b.lng - a.lng) * Math.PI / 180;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

const _mapStatus = (s) => ({ "Recebido": "novo", "novo": "novo", "aceito": "aceito", "producao": "producao", "Em produção": "producao", "pronto": "pronto", "Pronto": "pronto", "coletado": "coletado", "entrega": "entrega", "Saiu para entrega": "entrega", "concluido": "concluido", "entregue": "concluido", "Entregue": "concluido" }[s] || "novo");
const _mapTipo = (t) => t === "entrega" ? "delivery" : t === "retirada" ? "avulso" : t === "mesa" ? "mesa" : "whatsapp";
const _fromRow = (r) => ({
  id: r.id,
  numero: String(r.id || "").replace(/-/g, "").slice(0, 4).toUpperCase(),
  tipo: _mapTipo(r.tipo),
  cliente: r.cliente || "Cliente",
  telefone: r.telefone || "",
  endereco: r.endereco || "",
  itens: Array.isArray(r.itens) ? r.itens.map((it) => ({ n: it.nome || it.n || "Item", q: it.qtd || it.q || 1 })) : [],
  status: _mapStatus(r.status),
  createdAt: r.createdAt ? new Date(r.createdAt).getTime() : Date.now(),
  total: Number(r.total) || 0,
});
const liveStore = (function () {
  let orders = [], subs = [], started = false;
  const emit = () => subs.forEach((f) => f(orders.slice()));
  const refresh = async () => {
    try {
      const { data } = await supabase.from("pedidos").select("*").eq("storeId", STORE_ID).neq("status", "concluido").neq("status", "entregue").order("createdAt", { ascending: false });
      if (data) { orders = data.map(_fromRow); emit(); }
    } catch (e) {}
  };
  return {
    get: () => orders.slice(),
    sub: (f) => { subs.push(f); return () => { subs = subs.filter((s) => s !== f); }; },
    refresh,
    update: (id, patch) => {
      orders = orders.map((o) => o.id === id ? { ...o, ...patch } : o);
      emit();
      if (patch.status) { try { supabase.from("pedidos").update({ status: patch.status }).eq("id", id).then(() => {}); } catch (e) {} }
    },
    startSim: () => { if (started) return; started = true; refresh(); setInterval(refresh, 8000); },
  };
})();
function useLive() {
  const [orders, setOrders] = useState(liveStore.get());
  useEffect(() => { const un = liveStore.sub(setOrders); liveStore.startSim(); return un; }, []);
  return orders;
}
function useNewOrderSound(orders, enabled) {
  const seen = useRef(null);
  useEffect(() => {
    const ids = new Set(orders.map((o) => o.id));
    if (seen.current === null) { seen.current = ids; return; }
    let isNew = false; ids.forEach((id) => { if (!seen.current.has(id)) isNew = true; });
    seen.current = ids;
    if (isNew && enabled) beep();
  }, [orders, enabled]);
}
function useAudioAutoUnlock() {
  useEffect(() => {
    const h = () => { unlockAudio(); };
    window.addEventListener("pointerdown", h, { once: true });
    window.addEventListener("keydown", h, { once: true });
    unlockAudio();
    return () => { window.removeEventListener("pointerdown", h); window.removeEventListener("keydown", h); };
  }, []);
}
function useClock() {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  return now;
}
const fmtTimer = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
function TipoPill({ tipo, mesa }) {
  const map = { mesa: ["navy", "Mesa " + (mesa || "")], delivery: ["orange", "Delivery"], avulso: ["gray", "Balcão"], whatsapp: ["green", "WhatsApp"] };
  const [tone, txt] = map[tipo] || ["gray", tipo];
  return <Pill tone={tone}>{txt}</Pill>;
}
function SoundBtn({ on, onToggle }) {
  return <button onClick={onToggle} className="rounded-xl font-semibold inline-flex items-center gap-2 px-3 py-2 text-sm" style={{ background: on ? SOFT : NAVY, color: on ? ORANGE : "#fff" }}>{on ? <Volume2 size={16} /> : <VolumeX size={16} />}{on ? "Som ligado" : "Ativar som"}</button>;
}

function Cozinha() {
  const orders = useLive();
  const now = useClock();
  const [sound, setSound] = useState(true);
  useAudioAutoUnlock();
  useNewOrderSound(orders, sound);
  const toggle = () => { if (!sound) { unlockAudio(); beep(); setSound(true); } else setSound(false); };
  const cols = [["novo", "Novos / aceitos", "#C0392B", Flame], ["producao", "Em produção", "#D35400", ChefHat], ["pronto", "Prontos", "#1B7F4B", Check]];
  const next = { novo: "producao", producao: "pronto" };
  const label = { novo: "Iniciar produção", producao: "Marcar pronto" };
  return (
    <Section title="Cozinha (KDS)" desc="Pedidos em tempo real. Toque para avançar a produção." right={<SoundBtn on={sound} onToggle={toggle} />}>
      <div className="grid md:grid-cols-3 gap-4">
        {cols.map(([st, titulo, cor, Ic]) => {
          const list = orders.filter((o) => st === "novo" ? (o.status === "novo" || o.status === "aceito") : o.status === st);
          return (
            <div key={st}>
              <div className="flex items-center justify-between mb-2"><h3 className="font-bold inline-flex items-center gap-2" style={{ color: NAVY }}><Ic size={16} color={cor} />{titulo}</h3><span className="text-sm font-bold" style={{ color: cor }}>{list.length}</span></div>
              <div className="space-y-3">
                {list.length === 0 && <div className="text-sm rounded-xl p-4 text-center" style={{ background: "#FAFAFA", color: "#9AA0A6" }}>Vazio</div>}
                {list.map((o) => { const late = now - o.createdAt > 600000; return (
                  <Card key={o.id} className="p-4" style={{ borderLeft: "4px solid " + cor }}>
                    <div className="flex items-center justify-between">
                      <div className="font-bold" style={{ color: NAVY }}>#{o.numero} · {o.cliente}</div>
                      <span className="text-xs font-semibold inline-flex items-center gap-1" style={{ color: late ? "#C0392B" : "#9AA0A6" }}><Timer size={13} />{fmtTimer(now - o.createdAt)}</span>
                    </div>
                    <div className="mt-1 mb-3 flex items-center gap-2"><TipoPill tipo={o.tipo} mesa={o.mesa} />{o.status === "novo" && <Pill tone="red">Aguarda aceite</Pill>}</div>
                    <ul className="text-sm space-y-1 mb-3" style={{ color: "#4B5563" }}>{o.itens.map((it, i) => <li key={i}>{it.q}× {it.n}</li>)}</ul>
                    {st !== "pronto"
                      ? <Btn size="sm" className="w-full" icon={st === "novo" ? Flame : Check} onClick={() => liveStore.update(o.id, { status: next[st] })}>{label[st]}</Btn>
                      : (o.tipo === "delivery"
                        ? <div className="text-xs text-center py-2 rounded-lg" style={{ background: SOFT, color: ORANGE }}>Aguardando entregador</div>
                        : <Btn size="sm" variant="ghost" className="w-full" icon={Check} onClick={() => liveStore.update(o.id, { status: "entregue" })}>Entregar / concluir</Btn>)}
                  </Card>
                ); })}
              </div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}

function PedidosVivo({ toast }) {
  const orders = useLive();
  const now = useClock();
  const [sound, setSound] = useState(true);
  useAudioAutoUnlock();
  useNewOrderSound(orders, sound);
  const toggle = () => { if (!sound) { unlockAudio(); beep(); setSound(true); } else setSound(false); };
  const ativos = orders.filter((o) => o.status !== "concluido" && o.status !== "entregue");
  const stInfo = { novo: ["Novo", "red"], aceito: ["Aceito", "blue"], producao: ["Em produção", "orange"], pronto: ["Pronto", "green"], coletado: ["Coletado", "navy"], entrega: ["Saiu p/ entrega", "blue"] };
  return (
    <Section title="Pedidos ao vivo" desc="Aceite os pedidos que chegam e cobre a cozinha quando atrasar." right={<SoundBtn on={sound} onToggle={toggle} />}>
      <div className="space-y-2">
        {ativos.length === 0 && <Card className="p-8 text-center"><span className="text-sm" style={{ color: "#9AA0A6" }}>Nenhum pedido ativo.</span></Card>}
        {ativos.map((o) => { const [t, tone] = stInfo[o.status] || ["", "gray"]; const late = now - o.createdAt > 480000; return (
          <Card key={o.id} className="p-4 flex items-center justify-between gap-3 flex-wrap" style={o.urgent ? { borderColor: ORANGE, borderWidth: 2 } : {}}>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl flex items-center justify-center" style={{ background: SOFT }}><Receipt size={18} color={ORANGE} /></div>
              <div>
                <div className="font-bold inline-flex items-center gap-2" style={{ color: NAVY }}>#{o.numero} · {o.cliente} <TipoPill tipo={o.tipo} mesa={o.mesa} /></div>
                <div className="text-xs" style={{ color: "#9AA0A6" }}>{o.itens.map((it) => it.q + "× " + it.n).join(", ")}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs inline-flex items-center gap-1" style={{ color: late ? "#C0392B" : "#9AA0A6" }}><Timer size={13} />{fmtTimer(now - o.createdAt)}</span>
              <Pill tone={tone}>{t}</Pill>
              {o.status === "novo" && <Btn size="sm" icon={Check} onClick={() => { liveStore.update(o.id, { status: "aceito" }); toast("Pedido #" + o.numero + " aceito"); }}>Aceitar</Btn>}
              {(o.status === "aceito" || o.status === "producao") && <Btn size="sm" variant="ghost" icon={BellIcon} onClick={() => { liveStore.update(o.id, { urgent: true }); toast("Cozinha avisada sobre #" + o.numero); }}>Cobrar</Btn>}
            </div>
          </Card>
        ); })}
      </div>
    </Section>
  );
}

function Entregador({ toast }) {
  const orders = useLive();
  const [recusados, setRecusados] = useState([]);
  const [sound, setSound] = useState(false);
  const disp = orders.filter((o) => o.tipo === "delivery" && o.status === "pronto" && !recusados.includes(o.id))
    .map((o) => ({ ...o, km: o.lat ? distKm(STORE_COORD, { lat: o.lat, lng: o.lng }) : null }))
    .sort((a, b) => (a.km ?? 999) - (b.km ?? 999));
  const minhas = orders.filter((o) => o.status === "coletado" || o.status === "entrega");
  useNewOrderSound(disp, sound);
  const toggle = () => { if (!sound) { unlockAudio(); beep(); setSound(true); } else setSound(false); };
  const maps = (o) => window.open("https://www.google.com/maps/dir/?api=1&destination=" + encodeURIComponent(o.endereco), "_blank");
  return (
    <Section title="Entregador" desc="Aceite as entregas, veja o endereço e abra a rota no Google Maps." right={<SoundBtn on={sound} onToggle={toggle} />}>
      {minhas.length > 0 && (<>
        <h3 className="font-bold mb-2" style={{ color: NAVY }}>Minhas entregas</h3>
        <div className="space-y-2 mb-5">
          {minhas.map((o) => (
            <Card key={o.id} className="p-4">
              <div className="flex items-center justify-between"><div className="font-bold" style={{ color: NAVY }}>#{o.numero} · {o.cliente}</div><Pill tone="blue">{o.status === "coletado" ? "Coletado" : "A caminho"}</Pill></div>
              <div className="text-sm mt-1 flex items-center gap-1" style={{ color: "#6B7280" }}><MapPin size={14} />{o.endereco}</div>
              <div className="flex gap-2 mt-3">
                <Btn size="sm" icon={Navigation} onClick={() => maps(o)}>Rota no Maps</Btn>
                {o.status === "coletado"
                  ? <Btn size="sm" icon={Truck} onClick={() => { liveStore.update(o.id, { status: "entrega" }); toast("Saiu para entrega #" + o.numero); }}>Saiu para entrega</Btn>
                  : <Btn size="sm" variant="ghost" icon={Check} onClick={() => { liveStore.update(o.id, { status: "entregue" }); toast("Entrega #" + o.numero + " concluída"); }}>Entregue</Btn>}
              </div>
            </Card>
          ))}
        </div>
      </>)}
      <h3 className="font-bold mb-2" style={{ color: NAVY }}>Disponíveis para coletar</h3>
      <div className="space-y-2">
        {disp.length === 0 && <Card className="p-8 text-center"><span className="text-sm" style={{ color: "#9AA0A6" }}>Nenhuma entrega disponível agora.</span></Card>}
        {disp.map((o) => (
          <Card key={o.id} className="p-4">
            <div className="flex items-center justify-between"><div className="font-bold" style={{ color: NAVY }}>#{o.numero} · {o.cliente}</div>{o.km != null ? <span className="text-sm font-bold inline-flex items-center gap-1" style={{ color: ORANGE }}><Bike size={14} />{o.km.toFixed(1)} km</span> : <Pill tone="orange">Entrega</Pill>}</div>
            <div className="text-sm mt-1 flex items-center gap-1" style={{ color: "#6B7280" }}><MapPin size={14} />{o.endereco || "Endereço no pedido"}{o.bairro ? " · " + o.bairro : ""}</div>
            <div className="text-xs mt-1" style={{ color: "#9AA0A6" }}>{o.itens.map((it) => it.q + "× " + it.n).join(", ")}</div>
            <div className="flex gap-2 mt-3">
              <Btn size="sm" icon={ThumbsUp} onClick={() => { liveStore.update(o.id, { status: "coletado" }); toast("Pedido #" + o.numero + " coletado"); }}>Aceitar / coletar</Btn>
              <Btn size="sm" variant="ghost" icon={ThumbsDown} onClick={() => setRecusados((r) => [...r, o.id])}>Recusar</Btn>
              <Btn size="sm" variant="ghost" icon={Navigation} onClick={() => maps(o)}>Rota</Btn>
            </div>
          </Card>
        ))}
      </div>
    </Section>
  );
}

/* ============================ Shell admin ============================ */
const NAV = [
  { k: "dashboard", label: "Visão geral", icon: LayoutDashboard, C: Dashboard },
  { k: "pdv", label: "PDV / Frente de caixa", icon: ShoppingCart, C: PDV },
  { k: "cozinha", label: "Cozinha (KDS)", icon: ChefHat, C: Cozinha },
  { k: "pedidos", label: "Pedidos ao vivo", icon: BellIcon, C: PedidosVivo },
  { k: "entregador", label: "Entregador", icon: Bike, C: Entregador },
  { k: "cardapio", label: "Produtos & cardápio", icon: Utensils, C: Cardapio },
  { k: "estoque", label: "Estoque & fichas técnicas", icon: Boxes, C: Estoque },
  { k: "compras", label: "Compras & NF-e (XML)", icon: ClipboardList, C: Compras },
  { k: "fiscal", label: "Fiscal & impressora", icon: Printer, C: Fiscal },
  { k: "encomendas", label: "Encomendas", icon: Calendar, C: Encomendas },
  { k: "delivery", label: "Delivery", icon: Truck, C: Delivery },
  { k: "clientes", label: "Clientes & cashback", icon: Users, C: Clientes },
  { k: "clube", label: "Clube de pontos", icon: Gift, C: Clube },
  { k: "pagamentos", label: "Pagamentos & PDVs", icon: Wallet, C: Pagamentos },
  { k: "whatsapp", label: "Pedidos WhatsApp", icon: MessageCircle, C: Whats },
  { k: "usuarios", label: "Usuários & permissões", icon: UserCog, C: Usuarios },
  { k: "integracoes", label: "Integrações (código)", icon: Plug, C: Integracoes },
  { k: "relatorios", label: "Relatórios", icon: BarChart3, C: Relatorios },
];

function Admin({ onExit, startMod, operador }) {
  const [mod, setMod] = useState(startMod || "dashboard");
  const [open, setOpen] = useState(false);
  const [tour, setTour] = useState(null);
  const [toastMsg, setToastMsg] = useState(null);
  const toast = (m) => { setToastMsg(m); setTimeout(() => setToastMsg(null), 2600); };
  const Active = NAV.find((n) => n.k === mod).C;

  const liveOrders = useLive();
  useAudioAutoUnlock();
  const seenRef = useRef(null);
  const [alerta, setAlerta] = useState(null);
  useEffect(() => {
    const ids = new Set(liveOrders.map((o) => o.id));
    if (seenRef.current === null) {
      seenRef.current = ids;
      const pend = liveOrders.filter((o) => o.status === "novo");
      if (pend.length) { unlockAudio(); beep(); setAlerta({ cliente: pend[0].cliente, count: pend.length }); }
      return;
    }
    const novos = liveOrders.filter((o) => !seenRef.current.has(o.id));
    seenRef.current = ids;
    if (novos.length) { unlockAudio(); beep(); setAlerta({ cliente: novos[0].cliente, count: novos.length }); }
  }, [liveOrders]);

  const NavList = (
    <nav className="p-3 space-y-0.5">
      {NAV.map((n) => { const on = mod === n.k; const I = n.icon; return (
        <button key={n.k} onClick={() => { setMod(n.k); setOpen(false); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition" style={on ? { background: "rgba(255,86,48,.14)", color: "#fff" } : { color: "rgba(255,255,255,.7)" }}>
          <I size={18} color={on ? ORANGE : "rgba(255,255,255,.6)"} />{n.label}
        </button>
      ); })}
    </nav>
  );

  return (
    <div className="min-h-screen flex" style={{ background: "#F7F7F5" }}>
      {alerta && (
        <div className="fixed top-0 left-0 right-0 z-[60] px-4 py-3 flex items-center justify-between shadow-lg" style={{ background: ORANGE, color: "#fff" }}>
          <div className="flex items-center gap-2 font-semibold"><BellIcon size={18} />Novo pedido de {alerta.cliente}!{alerta.count > 1 ? " (+" + (alerta.count - 1) + " outros)" : ""}</div>
          <div className="flex items-center gap-2">
            <button onClick={() => { setMod("pedidos"); setAlerta(null); }} className="px-3 py-1.5 rounded-lg text-sm font-bold" style={{ background: "#fff", color: ORANGE }}>Ver pedidos</button>
            <button onClick={() => { unlockAudio(); beep(); }} className="h-8 w-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(255,255,255,.2)" }} title="Tocar som"><Volume2 size={16} color="#fff" /></button>
            <button onClick={() => setAlerta(null)} className="h-8 w-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(255,255,255,.2)" }}><X size={16} color="#fff" /></button>
          </div>
        </div>
      )}
      {/* sidebar desktop */}
      <aside className="hidden md:flex md:flex-col w-64 shrink-0" style={{ background: NAVY }}>
        <div className="p-4 flex items-center gap-2 border-b" style={{ borderColor: "rgba(255,255,255,.08)" }}>
          <ZipIcon size={34} /><span className="text-white font-bold text-lg" style={{ fontFamily: "Fredoka, sans-serif" }}>Zipão</span>
          <span className="ml-auto text-xs px-2 py-1 rounded-md" style={{ background: "rgba(255,255,255,.1)", color: "#fff" }}>ERP</span>
        </div>
        <div className="flex-1 overflow-y-auto">{NavList}</div>
        <button onClick={async () => { await supabase.auth.signOut(); onExit(); }} className="m-3 p-3 rounded-xl text-sm font-medium inline-flex items-center gap-2" style={{ color: "rgba(255,255,255,.7)", background: "rgba(255,255,255,.06)" }}><LogOut size={16} />Sair</button>
      </aside>

      {/* sidebar mobile */}
      {open && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="w-72 h-full overflow-y-auto" style={{ background: NAVY }}>
            <div className="p-4 flex items-center gap-2"><ZipIcon size={32} /><span className="text-white font-bold" style={{ fontFamily: "Fredoka, sans-serif" }}>Zipão</span><button className="ml-auto" onClick={() => setOpen(false)}><X color="#fff" size={22} /></button></div>
            {NavList}
          </div>
          <div className="flex-1" style={{ background: "rgba(0,0,0,.4)" }} onClick={() => setOpen(false)} />
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="bg-white border-b px-4 md:px-6 py-3 flex items-center gap-3" style={{ borderColor: "#ECECEC" }}>
          <button className="md:hidden" onClick={() => setOpen(true)}><Menu color={NAVY} /></button>
          <div className="relative hidden sm:block flex-1 max-w-md">
            <Search size={16} className="absolute left-3 top-2.5" color="#9AA0A6" />
            <input placeholder="Buscar produto, cliente, pedido..." className="w-full pl-9 pr-3 py-2 rounded-xl border text-sm outline-none" style={{ borderColor: "#E8E8E8" }} />
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Btn size="sm" variant="ghost" icon={Power} onClick={() => setTour(0)}>Tour guiado</Btn>
            <button className="h-9 w-9 rounded-xl flex items-center justify-center relative" style={{ background: "#F4F4F5" }}><Bell size={18} color={NAVY} /><span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full" style={{ background: ORANGE }} /></button>
            {operador && <span className="text-sm font-medium hidden sm:block" style={{ color: NAVY }}>{operador}</span>}
            <div className="h-9 w-9 rounded-full flex items-center justify-center text-white text-sm font-bold" style={{ background: ORANGE }}>{operador ? operador[0] : "A"}</div>
          </div>
        </header>
        <main className="p-4 md:p-6 overflow-y-auto flex-1"><Active toast={toast} /></main>
      </div>

      {tour !== null && <Tour step={tour} setStep={setTour} onModule={setMod} onClose={() => setTour(null)} />}
      {toastMsg && (
        <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 px-4 py-3 rounded-xl text-white text-sm font-medium flex items-center gap-2 shadow-lg" style={{ background: NAVY }}>
          <CheckCircle2 size={16} color={ORANGE} />{toastMsg}
        </div>
      )}
    </div>
  );
}

/* ============================ Root ============================ */
export default function App() {
  const [screen, setScreen] = useState("home");
  const [adminInit, setAdminInit] = useState({ mod: "dashboard", operador: null });
  const [toastMsg, setToastMsg] = useState(null);
  const [booting, setBooting] = useState(true);
  const toast = (m) => { setToastMsg(m); setTimeout(() => setToastMsg(null), 2400); };
  const goAdmin = (mod, operador) => { setAdminInit({ mod: mod || "dashboard", operador: operador || null }); setScreen("admin"); };
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data && data.session) { setAdminInit({ mod: "dashboard", operador: null }); setScreen("admin"); }
      setBooting(false);
    }).catch(() => setBooting(false));
  }, []);
  if (booting) {
    return <div className="min-h-screen flex items-center justify-center" style={{ background: CREAM }}><ZipIcon size={56} /></div>;
  }
  return (
    <div style={{ fontFamily: "ui-sans-serif, system-ui, sans-serif" }}>
      <style>{"@import url('https://fonts.googleapis.com/css2?family=Fredoka:wght@600&display=swap');"}</style>
      {screen === "home" && <Landing onLogin={() => setScreen("login")} onCliente={() => setScreen("cliente")} toast={toast} />}
      {screen === "login" && <Login onEnter={setScreen} onDono={() => goAdmin("dashboard", null)} />}
      {screen === "pdvlogin" && <PDVLogin onBack={() => setScreen("login")} onEnter={(op) => goAdmin("pdv", op)} />}
      {screen === "cadentregador" && <CourierSignup onBack={() => setScreen("login")} />}
      {screen === "admin" && <Admin onExit={() => setScreen("home")} startMod={adminInit.mod} operador={adminInit.operador} />}
      {screen === "cliente" && <ClienteApp onExit={() => setScreen("home")} toast={toast} />}
      {toastMsg && (
        <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 px-4 py-3 rounded-xl text-white text-sm font-medium flex items-center gap-2 shadow-lg" style={{ background: NAVY }}>
          <CheckCircle2 size={16} color={ORANGE} />{toastMsg}
        </div>
      )}
    </div>
  );
}
